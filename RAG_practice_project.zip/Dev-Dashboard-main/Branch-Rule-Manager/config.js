// Branch Rule Manager — Configuration
// Update these values for your GitHub Enterprise Server instance.

const CONFIG = {
    // Base URL of your GitHub Enterprise Server (no trailing slash)
    GHES_BASE_URL: 'https://github.apps.gevernova.net',

    // REST API base
    get API_BASE() {
        return `${this.GHES_BASE_URL}/api/v3`;
    },

    // GraphQL API endpoint
    get GRAPHQL_URL() {
        return `${this.GHES_BASE_URL}/api/graphql`;
    },

    // ---------- Access Control ----------
    // Organization that owns the teams
    ACCESS_ORG: 'gp-it',

    // Team slugs that grant access (user must be a member of ANY one of these)
    ACCESS_TEAM_SLUGS: [
        'gp-it-reviewers-avevae3d-uai-avevae3d',
        'gp-it-reviewers-aveva2d-uai-aveva2d',
        'gp-it-reviewers-cyplus-uai-cyplus',
        'gp-it-reviewers-dpd-lemur-uai-dpd-lemur',
        'gp-it-reviewers-eplan-uai-eplan',
        'gp-it-reviewers-hrsg-digitization-uai-hrsg-digitization',
        // Add more team slugs below:
        // 'devops-admins',
        // 'release-managers',
    ],

    // Individual users granted access even if they are not in any of the above teams
    ACCESS_USERS: [
        '503334193',
        '503271894',
    ],

    // ---------- Service PAT ----------
    // A PAT with admin access used for all GitHub API operations
    // (repo listing, reading/updating branch protection rules).
    // When set, users' personal tokens are used only for identity verification.
    // Required scopes for this PAT: repo, read:org
    SERVICE_PAT: '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',


    // ---------- Hidden Branches ----------
    // Branches to hide from the matching-branches column in the UI
    HIDDEN_BRANCHES: ['development', 'master', 'main'],

    // ---------- Audit Settings ----------
    // Log who unprotected/protected branches and why
    AUDIT_ENABLED: true,
    AUDIT_REPO_OWNER: '503334193',
    AUDIT_REPO_NAME: 'Dev-Dashboard',
    AUDIT_FILE_PATH: 'Branch-Rule-Manager/audit-log.json',
    AUDIT_BRANCH: 'audit-data',

    // ---------- PAT Scope Requirements ----------
    // Users need a PAT with repo scope to list repos they have access to.
    // The service account PAT handles branch protection operations.
    REQUIRED_SCOPES_DESCRIPTION: 'repo',
};
