// Branch Rule Manager — Application Logic
'use strict';

const App = (() => {
    // ===== State =====
    let token = null;
    let serviceToken = null;
    let currentUser = null;
    let repos = [];
    let selectedRepo = null;

    // ===== DOM Refs =====
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    // ===== Initialization =====
    function init() {
        // Pre-fill PAT from config if available
        if (CONFIG.DEFAULT_PAT) {
            $('#pat-input').value = CONFIG.DEFAULT_PAT;
        }
        serviceToken = CONFIG.SERVICE_PAT || null;
        token = sessionStorage.getItem('ghes_pat');
        if (token) {
            authenticate();
        } else {
            showLogin();
        }
        bindEvents();
    }

    function bindEvents() {
        $('#login-form').addEventListener('submit', handleLogin);
        $('#logout-btn').addEventListener('click', handleLogout);
        $('#repo-search').addEventListener('input', handleRepoSearch);
        $('#repo-search').addEventListener('keydown', handleSearchKeydown);
        $('#repo-search').addEventListener('focus', () => openDropdown());
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.repo-search-wrapper')) closeDropdown();
        });
    }

    // ===== Authentication =====
    async function handleLogin(e) {
        e.preventDefault();
        const pat = $('#pat-input').value.trim();
        if (!pat) return;

        token = pat;
        $('#login-btn').disabled = true;
        $('#login-btn').innerHTML = '<span class="spinner"></span> Signing in...';

        try {
            await authenticate();
        } catch (err) {
            token = null;
            sessionStorage.removeItem('ghes_pat');
            showLogin();
            showToast(err.message, 'error');
        } finally {
            $('#login-btn').disabled = false;
            $('#login-btn').textContent = 'Sign in';
        }
    }

    async function authenticate() {
        // Step 1: Get user info
        currentUser = await apiGet('/user', token);
        if (!currentUser || !currentUser.login) {
            throw new Error('Invalid token — could not authenticate.');
        }

        // Step 2: Show app and start loading repos immediately (optimistic)
        sessionStorage.setItem('ghes_pat', token);
        showApp();
        loadRepos();

        // Step 3: Check access in background — explicit user list OR team membership
        let isMember = false;

        // Check if user is explicitly listed
        if (Array.isArray(CONFIG.ACCESS_USERS) &&
            CONFIG.ACCESS_USERS.some(u => u.toLowerCase() === currentUser.login.toLowerCase())) {
            isMember = true;
        }

        if (!isMember) {
            // Fire all team membership checks in parallel
            const teamChecks = CONFIG.ACCESS_TEAM_SLUGS.map(teamSlug =>
                apiGet(
                    `/orgs/${encodeURIComponent(CONFIG.ACCESS_ORG)}/teams/${encodeURIComponent(teamSlug)}/memberships/${encodeURIComponent(currentUser.login)}`
                ).then(membership => ({ status: 'ok', membership }))
                 .catch(err => ({ status: 'error', err }))
            );

            const results = await Promise.all(teamChecks);
            let got403 = false;

            for (const result of results) {
                if (result.status === 'ok' && result.membership && result.membership.state === 'active') {
                    isMember = true;
                    break;
                }
                if (result.status === 'error' && result.err.status === 403) {
                    got403 = true;
                }
            }

            if (got403 && !isMember) {
                if (serviceToken) {
                    throw new Error('Service token configuration error: the SERVICE_PAT is missing the "read:org" scope.');
                } else {
                    throw new Error(
                        `Your PAT is missing the "read:org" scope. Please create a new token with scopes: ${CONFIG.REQUIRED_SCOPES_DESCRIPTION}`
                    );
                }
            }
        }

        // If access denied, kick back to denied screen
        if (!isMember) {
            token = null;
            sessionStorage.removeItem('ghes_pat');
            sessionStorage.removeItem(REPO_CACHE_KEY);
            repos = [];
            selectedRepo = null;
            showAccessDenied();
        }
    }

    function handleLogout() {
        token = null;
        currentUser = null;
        repos = [];
        selectedRepo = null;
        sessionStorage.removeItem('ghes_pat');
        sessionStorage.removeItem(REPO_CACHE_KEY);
        showLogin();
    }

    // ===== API Helpers =====
    async function apiGet(path, authToken) {
        authToken = authToken || serviceToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
            },
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.json();
    }

    async function apiGetAllPages(path, authToken) {
        authToken = authToken || serviceToken || token;
        let results = [];
        let page = 1;
        const separator = path.includes('?') ? '&' : '?';
        while (true) {
            const res = await fetch(`${CONFIG.API_BASE}${path}${separator}per_page=100&page=${page}`, {
                headers: {
                    'Accept': 'application/vnd.github+json',
                    'Authorization': `Bearer ${authToken}`,
                },
            });
            if (!res.ok) {
                const err = new Error(`API error: ${res.status}`);
                err.status = res.status;
                throw err;
            }
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) break;
            results = results.concat(data);
            if (data.length < 100) break;
            page++;
        }
        return results;
    }

    async function graphql(query, variables, authToken) {
        authToken = authToken || serviceToken || token;
        const res = await fetch(CONFIG.GRAPHQL_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`,
            },
            body: JSON.stringify({ query, variables }),
        });
        if (!res.ok) {
            const err = new Error(`GraphQL error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        const json = await res.json();
        if (json.errors && json.errors.length > 0) {
            throw new Error(json.errors.map(e => e.message).join('; '));
        }
        return json.data;
    }

    // ===== Audit Logging (unprotected branch) =====
    async function getAuditFile() {
        const path = `/repos/${encodeURIComponent(CONFIG.AUDIT_REPO_OWNER)}/${encodeURIComponent(CONFIG.AUDIT_REPO_NAME)}/contents/${encodeURIComponent(CONFIG.AUDIT_FILE_PATH)}?ref=${encodeURIComponent(CONFIG.AUDIT_BRANCH)}`;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${serviceToken}`,
            },
        });
        if (res.status === 404) {
            return { sha: null, entries: [] };
        }
        if (!res.ok) throw new Error(`Audit fetch failed: ${res.status}`);
        const data = await res.json();
        const decoded = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ''))));
        return { sha: data.sha, entries: JSON.parse(decoded) };
    }

    async function appendAuditEntry(entry, retries = 3) {
        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                const { sha, entries } = await getAuditFile();
                entries.push(entry);
                const updatedContent = btoa(unescape(encodeURIComponent(
                    JSON.stringify(entries, null, 2)
                )));
                const path = `/repos/${encodeURIComponent(CONFIG.AUDIT_REPO_OWNER)}/${encodeURIComponent(CONFIG.AUDIT_REPO_NAME)}/contents/${encodeURIComponent(CONFIG.AUDIT_FILE_PATH)}`;
                const body = {
                    message: `audit: ${entry.user} ${entry.action} ${entry.pattern} on ${entry.repo}`,
                    content: updatedContent,
                    branch: CONFIG.AUDIT_BRANCH,
                };
                if (sha) body.sha = sha;
                const res = await fetch(`${CONFIG.API_BASE}${path}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${serviceToken}`,
                    },
                    body: JSON.stringify(body),
                });
                if (res.status === 409 && attempt < retries) continue;
                if (!res.ok) throw new Error(`Audit write failed: ${res.status}`);
                return;
            } catch (err) {
                if (attempt === retries) throw err;
            }
        }
    }

    async function getAuditForRepo(repoFullName) {
        if (!CONFIG.AUDIT_ENABLED) return [];
        try {
            const { entries } = await getAuditFile();
            return entries
                .filter(e => e.repo === repoFullName)
                .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        } catch { return []; }
    }

    // ===== Most Used Repos =====
    const MOST_USED_KEY = 'ghes_most_used_repos';
    const MOST_USED_MAX = 5;

    function getMostUsedRepos() {
        try {
            const raw = localStorage.getItem(MOST_USED_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch { return []; }
    }

    function trackRepoUsage(repo) {
        const list = getMostUsedRepos();
        const existing = list.find(r => r.full_name === repo.full_name);
        if (existing) {
            existing.count++;
        } else {
            list.push({ full_name: repo.full_name, owner_login: repo.owner.login, name: repo.name, count: 1 });
        }
        list.sort((a, b) => b.count - a.count);
        localStorage.setItem(MOST_USED_KEY, JSON.stringify(list.slice(0, MOST_USED_MAX)));
    }

    function renderMostUsedRepos() {
        const container = $('#most-used-repos');
        const listEl = $('#most-used-list');
        const mostUsed = getMostUsedRepos();
        if (mostUsed.length === 0) {
            container.classList.add('hidden');
            return;
        }
        container.classList.remove('hidden');
        listEl.innerHTML = '';
        mostUsed.forEach(item => {
            const chip = document.createElement('button');
            chip.className = 'most-used-chip';
            chip.textContent = item.full_name;
            chip.addEventListener('click', () => {
                const repo = repos.find(r => r.full_name === item.full_name);
                if (repo) {
                    selectRepo(repo);
                } else {
                    // Minimal repo object for selection if repos haven't loaded yet
                    selectRepo({ full_name: item.full_name, owner: { login: item.owner_login }, name: item.name });
                }
            });
            listEl.appendChild(chip);
        });
    }

    // ===== Repository Loading =====
    let reposLoading = false;
    let highlightIndex = -1;
    let filteredRepos = [];
    let searchDebounceTimer = null;
    const REPO_CACHE_KEY = 'ghes_repos_cache';
    const REPO_CACHE_TTL = 5 * 60 * 1000; // 5 minutes

    function getCachedRepos() {
        try {
            const raw = sessionStorage.getItem(REPO_CACHE_KEY);
            if (!raw) return null;
            const cached = JSON.parse(raw);
            if (Date.now() - cached.ts > REPO_CACHE_TTL) {
                sessionStorage.removeItem(REPO_CACHE_KEY);
                return null;
            }
            return cached.data;
        } catch { return null; }
    }

    function setCachedRepos(data) {
        try {
            sessionStorage.setItem(REPO_CACHE_KEY, JSON.stringify({ ts: Date.now(), data }));
        } catch { /* storage full — ignore */ }
    }

    async function loadRepos() {
        showReposLoading();
        reposLoading = true;
        repos = [];

        // Try cache first for instant display
        const cached = getCachedRepos();
        if (cached && cached.length > 0) {
            repos = cached;
            repos.sort((a, b) => a.full_name.localeCompare(b.full_name));
            reposLoading = false;
            updateRepoCount();
            renderRepoDropdown(repos);
            // Refresh in background (non-blocking)
            fetchAllRepos(true);
            return;
        }

        await fetchAllRepos(false);
    }

    async function fetchAllRepos(silent) {
        if (!silent) {
            reposLoading = true;
        }
        try {
            // Use the user's PAT to list repos — so only repos they have access to are shown
            const firstPageData = await apiGetPage('/user/repos?sort=full_name', 1, token);
            if (!silent) {
                repos = firstPageData.data;
                repos.sort((a, b) => a.full_name.localeCompare(b.full_name));
                updateRepoCount();
                renderRepoDropdown(repos);
            }

            let allData = firstPageData.data;

            // If there are more pages, fetch them concurrently
            if (firstPageData.hasMore) {
                const pagePromises = [];
                for (let page = 2; page <= 20; page++) {
                    pagePromises.push(apiGetPage('/user/repos?sort=full_name', page, token));
                }
                const results = await Promise.allSettled(pagePromises);
                for (const result of results) {
                    if (result.status === 'fulfilled' && result.value.data.length > 0) {
                        allData = allData.concat(result.value.data);
                    }
                }
            }

            allData.sort((a, b) => a.full_name.localeCompare(b.full_name));
            repos = allData;
            setCachedRepos(allData);
            updateRepoCount();

            // Re-render dropdown
            const query = $('#repo-search').value.toLowerCase().trim();
            if (query) {
                handleRepoSearch();
            } else {
                renderRepoDropdown(repos);
            }
        } catch (err) {
            if (!silent) {
                showToast('Failed to load repositories: ' + err.message, 'error');
            }
        } finally {
            reposLoading = false;
        }
    }

    async function apiGetPage(path, page, authToken) {
        authToken = authToken || serviceToken || token;
        const separator = path.includes('?') ? '&' : '?';
        const res = await fetch(`${CONFIG.API_BASE}${path}${separator}per_page=100&page=${page}`, {
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
            },
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        const data = await res.json();
        return { data: Array.isArray(data) ? data : [], hasMore: Array.isArray(data) && data.length === 100 };
    }

    function updateRepoCount() {
        const countEl = $('#repo-count');
        if (reposLoading) {
            countEl.textContent = `${repos.length} repositories loaded (still fetching...)`;
        } else {
            countEl.textContent = `${repos.length} repositories`;
        }
    }

    function renderRepoDropdown(list) {
        filteredRepos = list;
        highlightIndex = -1;
        const dropdown = $('#repo-dropdown');
        const query = $('#repo-search').value.toLowerCase().trim();

        if (reposLoading && list.length === 0) {
            dropdown.innerHTML = `
                <div class="repo-dropdown-shimmer">
                    <div class="shimmer-line"></div>
                    <div class="shimmer-line"></div>
                    <div class="shimmer-line"></div>
                </div>`;
            return;
        }

        if (list.length === 0) {
            dropdown.innerHTML = `
                <div class="repo-dropdown-empty">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"/>
                    </svg>
                    <span>No repositories match "<strong>${escapeHtml(query)}</strong>"</span>
                </div>`;
            return;
        }

        // Virtual-render only first 50 items for performance
        const visibleItems = list.slice(0, 50);
        const fragment = document.createDocumentFragment();

        visibleItems.forEach((repo, idx) => {
            const item = document.createElement('div');
            item.className = 'repo-dropdown-item';
            item.dataset.index = idx;
            item.innerHTML = highlightMatch(repo, query);
            item.addEventListener('click', () => selectRepo(repo));
            fragment.appendChild(item);
        });

        if (list.length > 50) {
            const more = document.createElement('div');
            more.className = 'repo-dropdown-more';
            more.textContent = `+ ${list.length - 50} more — type to narrow results`;
            fragment.appendChild(more);
        }

        dropdown.innerHTML = '';
        dropdown.appendChild(fragment);
    }

    function highlightMatch(repo, query) {
        const owner = escapeHtml(repo.owner.login);
        const name = escapeHtml(repo.name);
        const full = `${owner} / ${name}`;

        if (!query) {
            return `<span class="repo-owner">${owner} / </span>${name}`;
        }

        // Find match position in the full name (case-insensitive)
        const lowerFull = repo.full_name.toLowerCase();
        const matchIdx = lowerFull.indexOf(query);
        if (matchIdx === -1) {
            return `<span class="repo-owner">${owner} / </span>${name}`;
        }

        // Highlight in the display string
        const displayFull = `${owner} / ${name}`;
        // Adjust index for display (owner/name vs owner / name)
        const displayLower = displayFull.toLowerCase();
        const dIdx = displayLower.indexOf(query);
        if (dIdx === -1) {
            return `<span class="repo-owner">${owner} / </span>${name}`;
        }

        const before = displayFull.slice(0, dIdx);
        const match = displayFull.slice(dIdx, dIdx + query.length);
        const after = displayFull.slice(dIdx + query.length);
        return `${before}<mark class="search-highlight">${match}</mark>${after}`;
    }

    function handleRepoSearch() {
        clearTimeout(searchDebounceTimer);
        searchDebounceTimer = setTimeout(() => {
            const query = $('#repo-search').value.toLowerCase().trim();
            const filtered = query
                ? repos.filter(r => r.full_name.toLowerCase().includes(query))
                : repos;
            renderRepoDropdown(filtered);
            openDropdown();
        }, 120);
    }

    function handleSearchKeydown(e) {
        const dropdown = $('#repo-dropdown');
        if (!dropdown.classList.contains('open')) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            highlightIndex = Math.min(highlightIndex + 1, Math.min(filteredRepos.length - 1, 49));
            updateHighlight();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            highlightIndex = Math.max(highlightIndex - 1, 0);
            updateHighlight();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightIndex >= 0 && highlightIndex < filteredRepos.length) {
                selectRepo(filteredRepos[highlightIndex]);
            }
        } else if (e.key === 'Escape') {
            closeDropdown();
            $('#repo-search').blur();
        }
    }

    function updateHighlight() {
        const dropdown = $('#repo-dropdown');
        dropdown.querySelectorAll('.repo-dropdown-item').forEach((item, idx) => {
            item.classList.toggle('highlighted', idx === highlightIndex);
        });
        // Scroll highlighted item into view
        const highlighted = dropdown.querySelector('.repo-dropdown-item.highlighted');
        if (highlighted) {
            highlighted.scrollIntoView({ block: 'nearest' });
        }
    }

    function openDropdown() {
        $('#repo-dropdown').classList.add('open');
    }

    function closeDropdown() {
        $('#repo-dropdown').classList.remove('open');
        highlightIndex = -1;
    }

    function selectRepo(repo) {
        selectedRepo = repo;
        $('#repo-search').value = repo.full_name;
        closeDropdown();
        trackRepoUsage(repo);
        renderMostUsedRepos();
        loadBranchProtectionRules();
    }

    function showReposLoading() {
        $('#repo-count').textContent = 'Loading repositories...';
    }

    // ===== Branch Protection Rules =====
    // Fast query — no matchingRefs (expensive server-side)
    const RULES_QUERY_FAST = `
        query($owner: String!, $name: String!) {
            repository(owner: $owner, name: $name) {
                branchProtectionRules(first: 100) {
                    nodes {
                        id
                        pattern
                        requiresApprovingReviews
                        requiresStatusChecks
                        isAdminEnforced
                        restrictsPushes
                        requiresLinearHistory
                    }
                }
            }
        }
    `;

    // Separate query to fetch matching refs for a single rule
    const MATCHING_REFS_QUERY = `
        query($owner: String!, $name: String!) {
            repository(owner: $owner, name: $name) {
                branchProtectionRules(first: 100) {
                    nodes {
                        id
                        matchingRefs(first: 100) {
                            nodes { name }
                        }
                    }
                }
            }
        }
    `;

    const UPDATE_RULE_MUTATION = `
        mutation($ruleId: ID!, $pattern: String!) {
            updateBranchProtectionRule(input: {
                branchProtectionRuleId: $ruleId,
                pattern: $pattern
            }) {
                branchProtectionRule {
                    id
                    pattern
                }
            }
        }
    `;

    let rulesAbortController = null;

    async function loadBranchProtectionRules() {
        if (!selectedRepo) return;

        // Abort any in-flight rules request for a previously selected repo
        if (rulesAbortController) rulesAbortController.abort();
        rulesAbortController = new AbortController();
        const signal = rulesAbortController.signal;

        const section = $('#rules-section');
        section.classList.remove('hidden');
        $('#rules-table-body').innerHTML = '';
        $('#rules-loading').classList.remove('hidden');
        $('#rules-empty').classList.add('hidden');
        $('#rules-table').classList.add('hidden');

        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;

        try {
            // Use service token for reading protection rules (needs admin access)
            const rulesPromise = graphql(RULES_QUERY_FAST, { owner, name }, serviceToken);
            const refsPromise = graphql(MATCHING_REFS_QUERY, { owner, name }, serviceToken);

            const data = await rulesPromise;
            if (signal.aborted) return;

            const allRules = data.repository.branchProtectionRules.nodes;
            const rules = allRules.filter(r => !CONFIG.HIDDEN_BRANCHES.includes(r.pattern));
            $('#rules-loading').classList.add('hidden');

            if (rules.length === 0) {
                $('#rules-empty').classList.remove('hidden');
                return;
            }

            // Render immediately with placeholders for branches
            $('#rules-table').classList.remove('hidden');
            renderRulesTable(rules.map(r => ({ ...r, matchingRefs: null })));

            // Await the refs query (already in-flight)
            try {
                const refsData = await refsPromise;
                if (signal.aborted) return;

                const refsNodes = refsData.repository.branchProtectionRules.nodes;
                const refsMap = {};
                refsNodes.forEach(n => { refsMap[n.id] = n.matchingRefs.nodes.map(r => r.name); });

                // Update the table in place
                const tbody = $('#rules-table-body');
                tbody.querySelectorAll('[data-rule-id]').forEach(btn => {
                    const ruleId = btn.dataset.ruleId;
                    const tr = btn.closest('tr');
                    const branchCell = tr.querySelector('.matching-branches');
                    if (branchCell && refsMap[ruleId]) {
                        const branches = refsMap[ruleId].filter(b => !CONFIG.HIDDEN_BRANCHES.includes(b));
                        branchCell.innerHTML = branches.length > 0
                            ? branches.map(b => `<span class="branch-tag">${escapeHtml(b)}</span>`).join('')
                            : '<span class="no-branches">No matching branches</span>';
                    }
                });
            } catch (refErr) {
                if (signal.aborted) return;
                console.warn('Failed to load matching branches:', refErr.message);
            }
        } catch (err) {
            if (signal.aborted) return;
            $('#rules-loading').classList.add('hidden');
            showToast('Failed to load protection rules: ' + err.message, 'error');
        }

        // Load audit history in background
        if (CONFIG.AUDIT_ENABLED) {
            loadAuditHistory(selectedRepo.full_name);
        }
    }

    // ===== Audit History UI =====
    async function loadAuditHistory(repoFullName) {
        const container = $('#audit-history');
        const listEl = $('#audit-list');
        container.classList.add('hidden');
        listEl.innerHTML = '';

        try {
            const entries = await getAuditForRepo(repoFullName);
            if (entries.length === 0) {
                container.classList.add('hidden');
                return;
            }

            const recent = entries.slice(0, 5);
            container.classList.remove('hidden');
            listEl.innerHTML = recent.map(e => {
                const date = new Date(e.timestamp);
                const timeAgo = formatTimeAgo(date);
                const isUnprotect = e.action === 'unprotect';
                const icon = isUnprotect
                    ? '<svg width="12" height="12" viewBox="0 0 16 16" fill="var(--color-danger)"><path d="M4.47.22A.749.749 0 0 1 5 0h6c.199 0 .389.079.53.22l4.25 4.25c.141.14.22.331.22.53v6a.749.749 0 0 1-.22.53l-4.25 4.25A.749.749 0 0 1 11 16H5a.749.749 0 0 1-.53-.22L.22 11.53A.749.749 0 0 1 0 11V5c0-.199.079-.389.22-.53Zm.84 1.28L1.5 5.31v5.38l3.81 3.81h5.38l3.81-3.81V5.31L10.69 1.5ZM8 4a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"/></svg>'
                    : '<svg width="12" height="12" viewBox="0 0 16 16" fill="var(--color-success)"><path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.28 5.78-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L6.75 8.19l3.47-3.47a.75.75 0 1 1 1.06 1.06z"/></svg>';
                const reasonHtml = e.reason ? `<div class="audit-reason">${escapeHtml(e.reason)}</div>` : '';
                return `
                    <div class="audit-entry ${isUnprotect ? 'audit-unprotect' : 'audit-protect'}">
                        <div class="audit-header">
                            ${icon}
                            <strong>${escapeHtml(e.user)}</strong>
                            <span class="audit-action">${isUnprotect ? 'unprotected' : 'protected'}</span>
                            <code>${escapeHtml(e.pattern)}</code>
                            <span class="audit-time" title="${escapeAttr(date.toLocaleString())}">${escapeHtml(timeAgo)}</span>
                        </div>
                        ${reasonHtml}
                    </div>
                `;
            }).join('');
        } catch (err) {
            console.warn('Failed to load audit history:', err.message);
        }
    }

    function formatTimeAgo(date) {
        const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
        if (seconds < 60) return 'just now';
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;
        const days = Math.floor(hours / 24);
        if (days < 30) return `${days}d ago`;
        return date.toLocaleDateString();
    }

    function renderRulesTable(rules) {
        const tbody = $('#rules-table-body');
        tbody.innerHTML = '';

        rules.forEach(rule => {
            const isUnprotected = rule.pattern.endsWith('--');
            const displayPattern = rule.pattern;
            const hasBranches = rule.matchingRefs && rule.matchingRefs.nodes;
            const matchingBranches = hasBranches
                ? rule.matchingRefs.nodes.map(n => n.name).filter(b => !CONFIG.HIDDEN_BRANCHES.includes(b))
                : [];

            let branchesHtml;
            if (!rule.matchingRefs) {
                branchesHtml = '<span class="branches-loading"><span class="spinner spinner-xs"></span> Loading...</span>';
            } else if (matchingBranches.length > 0) {
                branchesHtml = matchingBranches.map(b => `<span class="branch-tag">${escapeHtml(b)}</span>`).join('');
            } else {
                branchesHtml = '<span class="no-branches">No matching branches</span>';
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="pattern-cell">${escapeHtml(displayPattern)}</td>
                <td>
                    ${isUnprotected
                        ? '<span class="badge badge-unprotected"><svg width="12" height="12" viewBox="0 0 16 16"><path fill="currentColor" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.28 5.78-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L6.75 8.19l3.47-3.47a.75.75 0 1 1 1.06 1.06z"/></svg> Unprotected</span>'
                        : '<span class="badge badge-protected"><svg width="12" height="12" viewBox="0 0 16 16"><path fill="currentColor" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.28 5.78-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L6.75 8.19l3.47-3.47a.75.75 0 1 1 1.06 1.06z"/></svg> Protected</span>'
                    }
                </td>
                <td>
                    <div class="matching-branches">
                        ${branchesHtml}
                    </div>
                </td>
                <td>
                    ${isUnprotected
                        ? `<button class="btn btn-success btn-sm" data-action="protect" data-rule-id="${escapeAttr(rule.id)}" data-pattern="${escapeAttr(rule.pattern)}">Protect</button>`
                        : `<button class="btn btn-danger btn-sm" data-action="unprotect" data-rule-id="${escapeAttr(rule.id)}" data-pattern="${escapeAttr(rule.pattern)}">Unprotect</button>`
                    }
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Event delegation — single listener on tbody instead of per-button
        if (!tbody.dataset.delegated) {
            tbody.addEventListener('click', (e) => {
                const btn = e.target.closest('[data-action]');
                if (!btn) return;
                showConfirmDialog(btn.dataset.action, btn.dataset.ruleId, btn.dataset.pattern);
            });
            tbody.dataset.delegated = '1';
        }
    }

    // ===== Confirm Dialog =====
    function showConfirmDialog(action, ruleId, pattern) {
        const overlay = document.createElement('div');
        overlay.className = 'dialog-overlay';

        const basePattern = action === 'protect' ? pattern.replace(/--$/, '') : pattern;
        const newPattern = action === 'unprotect' ? pattern + '--' : pattern.replace(/--$/, '');
        const verb = action === 'unprotect' ? 'unprotect' : 're-protect';

        const reasonHtml = action === 'unprotect' ? `
            <div class="dialog-field">
                <label for="unprotect-reason">Reason <span class="required">*</span></label>
                <textarea id="unprotect-reason" rows="3" placeholder="Why are you unprotecting this branch?" required></textarea>
            </div>
        ` : '';

        overlay.innerHTML = `
            <div class="dialog">
                <h3>${action === 'unprotect' ? 'Unprotect Branch Rule' : 'Protect Branch Rule'}</h3>
                <p>
                    Are you sure you want to ${verb} <code>${escapeHtml(basePattern)}</code>?<br>
                    The pattern will change from <code>${escapeHtml(pattern)}</code> to <code>${escapeHtml(newPattern)}</code>.
                </p>
                ${reasonHtml}
                <div class="dialog-actions">
                    <button class="btn" id="dialog-cancel">Cancel</button>
                    <button class="btn ${action === 'unprotect' ? 'btn-danger' : 'btn-primary'}" id="dialog-confirm" ${action === 'unprotect' ? 'disabled' : ''}>
                        ${action === 'unprotect' ? 'Unprotect' : 'Protect'}
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        // Enable confirm button only when reason is provided (for unprotect)
        if (action === 'unprotect') {
            const textarea = overlay.querySelector('#unprotect-reason');
            const confirmBtn = overlay.querySelector('#dialog-confirm');
            textarea.addEventListener('input', () => {
                confirmBtn.disabled = textarea.value.trim().length < 5;
            });
            textarea.focus();
        }

        overlay.querySelector('#dialog-cancel').addEventListener('click', () => {
            overlay.remove();
        });

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });

        overlay.querySelector('#dialog-confirm').addEventListener('click', async () => {
            const confirmBtn = overlay.querySelector('#dialog-confirm');
            const reason = action === 'unprotect'
                ? overlay.querySelector('#unprotect-reason').value.trim()
                : '';

            confirmBtn.disabled = true;
            confirmBtn.innerHTML = '<span class="spinner"></span>';

            // Optimistic UI: close dialog and update table immediately
            overlay.remove();
            optimisticUpdateRule(ruleId, pattern, newPattern, action);

            try {
                // Use service account for protect/unprotect operations
                await graphql(UPDATE_RULE_MUTATION, {
                    ruleId: ruleId,
                    pattern: newPattern,
                }, serviceToken);

                // Log audit entry (fire-and-forget)
                if (CONFIG.AUDIT_ENABLED) {
                    appendAuditEntry({
                        repo: selectedRepo.full_name,
                        pattern: basePattern,
                        action: action,
                        user: currentUser.login,
                        reason: reason,
                        timestamp: new Date().toISOString(),
                    }).catch(err => console.warn('Audit log failed:', err.message));
                }

                showToast(
                    `Successfully ${action === 'unprotect' ? 'unprotected' : 'protected'} "${basePattern}"`,
                    'success'
                );
            } catch (err) {
                showToast('Failed to update rule: ' + err.message, 'error');
                // Revert: reload from server
                loadBranchProtectionRules();
            }
        });
    }

    function optimisticUpdateRule(ruleId, oldPattern, newPattern, action) {
        const tbody = $('#rules-table-body');
        const btn = tbody.querySelector(`[data-rule-id="${CSS.escape(ruleId)}"]`);
        if (!btn) return;

        const tr = btn.closest('tr');
        const isNowUnprotected = newPattern.endsWith('--');

        // Update pattern cell
        const patternCell = tr.querySelector('.pattern-cell');
        if (patternCell) patternCell.textContent = newPattern;

        // Update status badge
        const statusCell = tr.children[1];
        if (statusCell) {
            statusCell.innerHTML = isNowUnprotected
                ? '<span class="badge badge-unprotected"><svg width="12" height="12" viewBox="0 0 16 16"><path fill="currentColor" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.28 5.78-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L6.75 8.19l3.47-3.47a.75.75 0 1 1 1.06 1.06z"/></svg> Unprotected</span>'
                : '<span class="badge badge-protected"><svg width="12" height="12" viewBox="0 0 16 16"><path fill="currentColor" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.28 5.78-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L6.75 8.19l3.47-3.47a.75.75 0 1 1 1.06 1.06z"/></svg> Protected</span>';
        }

        // Update action button
        const actionCell = tr.children[3];
        if (actionCell) {
            const newAction = isNowUnprotected ? 'protect' : 'unprotect';
            actionCell.innerHTML = isNowUnprotected
                ? `<button class="btn btn-success btn-sm" data-action="protect" data-rule-id="${escapeAttr(ruleId)}" data-pattern="${escapeAttr(newPattern)}">Protect</button>`
                : `<button class="btn btn-danger btn-sm" data-action="unprotect" data-rule-id="${escapeAttr(ruleId)}" data-pattern="${escapeAttr(newPattern)}">Unprotect</button>`;
            // Event delegation on tbody handles clicks — no per-button binding needed
        }
    }

    // ===== View Management =====
    function showLogin() {
        $('#view-login').classList.remove('hidden');
        $('#view-app').classList.add('hidden');
        $('#view-denied').classList.add('hidden');
        $('#user-info').classList.add('hidden');
        $('#logout-btn').classList.add('hidden');
        $('#pat-input').value = CONFIG.DEFAULT_PAT || '';
    }

    function showApp() {
        $('#view-login').classList.add('hidden');
        $('#view-app').classList.remove('hidden');
        $('#view-denied').classList.add('hidden');
        $('#user-info').classList.remove('hidden');
        $('#logout-btn').classList.remove('hidden');
        $('#rules-section').classList.add('hidden');

        // Populate user info
        if (currentUser) {
            loadAvatar(currentUser.avatar_url);
            $('#user-name').textContent = currentUser.login;
        }

        // Reset search
        $('#repo-search').value = '';
        $('#rules-table-body').innerHTML = '';

        // Show most used repos
        renderMostUsedRepos();
    }

    function showAccessDenied() {
        $('#view-login').classList.add('hidden');
        $('#view-app').classList.add('hidden');
        $('#view-denied').classList.remove('hidden');
        $('#user-info').classList.add('hidden');
        $('#logout-btn').classList.remove('hidden');
        const teamList = CONFIG.ACCESS_TEAM_SLUGS
            .map(t => `<strong>${escapeHtml(CONFIG.ACCESS_ORG)}/${escapeHtml(t)}</strong>`)
            .join(' or ');
        $('#denied-message').innerHTML =
            `You must be a member of one of these teams to use this tool: ${teamList}.`;
    }

    // ===== Toast Notifications =====
    function showToast(message, type = 'info') {
        const container = $('#toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 4000);
    }

    // ===== Utility =====
    const _escDiv = document.createElement('div');
    const _escText = document.createTextNode('');
    _escDiv.appendChild(_escText);
    function escapeHtml(str) {
        _escText.nodeValue = str;
        return _escDiv.innerHTML;
    }

    function escapeAttr(str) {
        return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    async function loadAvatar(url) {
        const img = $('#user-avatar');
        // Always use GitHub logo instead of user avatar
        img.src = '../logos/Github.png';
        return;

        if (!url) {
            img.src = generateFallbackAvatar(currentUser.login);
            return;
        }

        // Strategy 1: Try authenticated fetch (GHES internal avatars)
        try {
            const res = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` },
                redirect: 'follow',
            });
            if (res.ok) {
                const blob = await res.blob();
                if (blob.size > 0) {
                    img.src = URL.createObjectURL(blob);
                    return;
                }
            }
        } catch { /* continue to next strategy */ }

        // Strategy 2: Try direct URL without auth (some GHES setups serve public avatars)
        try {
            await new Promise((resolve, reject) => {
                const testImg = new Image();
                testImg.onload = resolve;
                testImg.onerror = reject;
                testImg.src = url;
            });
            img.src = url;
            return;
        } catch { /* continue to fallback */ }

        // Strategy 3: Try the API-based avatar endpoint
        try {
            const res = await fetch(`${CONFIG.API_BASE}/users/${encodeURIComponent(currentUser.login)}`, {
                headers: {
                    'Accept': 'application/vnd.github+json',
                    'Authorization': `Bearer ${token}`,
                },
            });
            if (res.ok) {
                const userData = await res.json();
                if (userData.avatar_url) {
                    const avatarRes = await fetch(userData.avatar_url, { redirect: 'follow' });
                    if (avatarRes.ok) {
                        const blob = await avatarRes.blob();
                        if (blob.size > 0) {
                            img.src = URL.createObjectURL(blob);
                            return;
                        }
                    }
                }
            }
        } catch { /* continue to fallback */ }

        // Final fallback: generated avatar with user's initial
        img.src = generateFallbackAvatar(currentUser.login);
    }

    function generateFallbackAvatar(username) {
        const initial = (username || '?').charAt(0).toUpperCase();
        // Generate a consistent color from the username
        let hash = 0;
        for (let i = 0; i < username.length; i++) {
            hash = username.charCodeAt(i) + ((hash << 5) - hash);
        }
        const hue = Math.abs(hash) % 360;
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
            <rect width="64" height="64" rx="32" fill="hsl(${hue}, 50%, 40%)"/>
            <text x="32" y="32" text-anchor="middle" dominant-baseline="central"
                  font-family="sans-serif" font-size="28" font-weight="600" fill="white">${initial}</text>
        </svg>`;
        return 'data:image/svg+xml,' + encodeURIComponent(svg);
    }

    // ===== Public API =====
    return { init };
})();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', App.init);
} else {
    App.init();
}
