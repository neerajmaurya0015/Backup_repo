// AI PR Reviewer — Configuration
// Update these values for your GitHub Enterprise Server and AI endpoint.

const CONFIG = {
    // Base URL of your GitHub Enterprise Server (no trailing slash)
    GHES_BASE_URL: 'https://github.apps.gevernova.net',

    // REST API base
    get API_BASE() {
        return `${this.GHES_BASE_URL}/api/v3`;
    },

    // ---------- Access Control ----------
    ACCESS_ORG: 'gp-it',

    ACCESS_TEAM_SLUGS: [
        'gp-it-reviewers-avevae3d-uai-avevae3d',
        'gp-it-reviewers-aveva2d-uai-aveva2d',
        'gp-it-reviewers-cyplus-uai-cyplus',
        'gp-it-reviewers-dpd-lemur-uai-dpd-lemur',
        'gp-it-reviewers-eplan-uai-eplan',
        'gp-it-reviewers-hrsg-digitization-uai-hrsg-digitization',
    ],

    ACCESS_USERS: [
        '503334193',
        '503271894',
    ],

    // ---------- Tokens ----------
    // Pre-fill PAT on login screen (optional, leave empty string to skip)
    DEFAULT_PAT: '',

    // Service PAT for API operations (repo listing, PR reading)
    SERVICE_PAT: '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',

    // ---------- Audit Settings ----------
    // Store AI review audit data in a dedicated branch of the Dev-Dashboard repo
    AUDIT_REPO_OWNER: '503334193',
    AUDIT_REPO_NAME: 'Dev-Dashboard',
    AUDIT_BRANCH: 'audit-data',

    // ---------- AI Configuration (Azure OpenAI via internal proxy) ----------
    // Internal LLM proxy — data stays within the company network.
    // Prefer setting the full chat endpoint path (example: https://host/v1/chat/completions).
    // If only a base URL is provided, app.js will try common fallback paths automatically.
    AI_ENDPOINT: 'https://dev-gateway.apps.gevernova.net',
    AI_API_KEY: 'sk-iuu5YcRBMIpxZek7spX0Kw',
    AI_MODEL: 'bedrock-claude-sonnet-4.5',
    AI_MAX_TOKENS: 16384,      // Must be high for reasoning models (reasoning + output share this budget)
    AI_TEMPERATURE: 0.2,       // Lower = more deterministic; set to null to omit from the request
    AI_APPLY_CODING_STANDARDS: true, // Set false to skip coding standards injection

    // ---------- Coding Standards (condensed from wiki) ----------
    // Full reference: https://pages.github.apps.gevernova.net/gp-it/wiki/CodingStandard/
    AI_CODING_STANDARDS_URL: 'https://pages.github.apps.gevernova.net/gp-it/wiki/CodingStandard/',

    AI_CODING_STANDARDS: {
        PML: `PML Coding Standards (MUST rules):
- camelCase for variables, methods, form members (e.g. !isValidName, !this.getLength())
- UPPER CASE for object identifiers (e.g. object ISOBOOK())
- UPPER CASE for PDMS commands (NEW, DELETE, CURRENT SESSION) — never abbreviated
- lower case for PML commands (if, do, endif, handle, endmethod)
- File naming: era + <moduleCode> + <appCode> + <description> + .<ext> (e.g. eraModVolumeAssistant.pmlfrm)
- Boolean vars MUST start with: is, has, can, needs (positive form preferred)
- Array vars MUST end with 's' (e.g. !branMembers)
- DBREF vars end with 'Refe'; string DBREF vars end with 'RefNo'
- No abbreviations in variable names (!fileName not !fn)
- Declare all variables at head of function/method with comment block
- Method size max 55 lines; line length max 120 characters
- Indent 2 spaces for control structures; blanks around operators and commas
- NO GOLABEL or jump statements; NO synonyms; NO macros (avoid)
- Avoid handle commands — query state instead; explicit type conversions (no $ character)
- No overloading of core objects (ARRAY, STRING, etc.)
- SESE rule (single entry single exit) — no mid-function returns except at start
- Return values must be evaluated before return line (not return !this.getValue())
- Forms are front-end only — no business logic in form code; use separate objects
- Standard GE header required on functions, objects, and forms
- Logical expressions: if-clause must use logical variable (not !currentValue.eq(1))
- Inset expressions must be sorted alphabetically`,

        CSHARP: `C# Coding Standards (MUST rules):
- Namespace: YourCompany.ProjectName.Subsystem
- PascalCase for classes, interfaces (prefix I), methods, properties
- camelCase for local variables, parameters, private fields
- UPPER_SNAKE_CASE for constants (e.g. MAX_RETRY_ATTEMPTS)
- 4-space indentation; Allman brace style (opening brace on new line)
- Line length max 120 characters
- SOLID principles: Single Responsibility, Open/Closed, Liskov, Interface Segregation, Dependency Inversion
- DRY: no duplicate code — extract reusable methods/classes
- No long methods — break into smaller focused methods with clear responsibilities
- No large classes — split by Single Responsibility Principle
- No long parameter lists — use objects/DTOs to group related parameters
- No magic numbers — use named constants
- Prefer polymorphism/strategy patterns over switch statements
- Input validation and sanitization on all user inputs
- No hardcoded secrets, API keys, or connection strings — use environment variables
- Secure error handling: no sensitive data in exception messages; log details server-side
- XML documentation comments on all public APIs, classes, methods
- Avoid global/mutable state — prefer dependency injection and immutability
- Write unit tests (MSTest/NUnit) for all business logic
- Git: feature branches, descriptive commit messages in present tense (feat:, fix:)
- Avoid code smells: feature envy, inconsistent naming, excessive comments
- Minimize cognitive and cyclomatic complexity — limit nesting depth`,

        UDA: `UDA Naming Standards:
- All GE UDAs for PDMS must start with prefix POW followed by meaningful identifier (e.g. POWPRESure)
- All GE UDAs for E3D must start with prefix ERA followed by meaningful identifier`,

        PML_CHECKLIST: `PML PR Review Checklist (MUST verify each item):
- Variable names follow PML naming conventions (camelCase, boolean prefix, array suffix, DBREF suffix)
- All variables are declared at the top of the function/method and sorted properly
- Revision history is updated in ALL modified PML files with proper date format
- AreaHistory file is updated to reflect the changes
- User Bulletin content is present and updated in the PR body with proper # UserBulletin tag
- User guidelines document is updated if applicable
- MD file changes render properly and are visible inside the Aveva module
- PR Title follows the correct format convention
- Rally Link is included and correct in the PR body
- No extra leading or trailing spaces in PR Body image paths
- Proper Label is selected on the PR
- Test cases exist in Rally and are passing
- QA Testing is complete before squash and merge
- Demo has been completed with the requester
- If menu items were added/deleted (new buttons), ALL corresponding images in documentation are updated
- No existing images in the documentation folder have been deleted (they are referenced in multiple places including PR body for User Bulletin content)
- Documentation index (table of contents at top) is updated wherever required
- Documentation TOC links are in lower case with all spaces replaced by "-" character
- Newly added files are placed in the correct directory
- pml.index file has been updated using the Rehash Tool (NOT Piranha tool)`,
    },

    // ---------- PR Defaults ----------
    MAX_DIFF_SIZE: 100000,     // Skip AI review if diff exceeds this many characters
    CHUNK_SIZE: 60000,         // Max characters per chunk when splitting large diffs
    AI_CHUNK_CONCURRENCY: 3,   // Number of chunks to review in parallel (higher = faster but more API load)
    PRS_PER_PAGE: 30,          // PRs to show per page

    // ---------- PAT Scope Requirements ----------
    REQUIRED_SCOPES_DESCRIPTION: 'repo, read:org',
};
