// AI PR Reviewer — Application Logic
'use strict';

const App = (() => {
    // ===== State =====
    let token = null;
    let serviceToken = null;
    let currentUser = null;
    let repos = [];
    let selectedRepo = null;
    let prs = [];
    let currentPR = null;
    let currentDiff = '';
    let conversationMessages = [];
    let inlineComments = [];
    let inlineCommentsVisible = true;
    let parsedDiffCache = { raw: '', files: [] };

    // ===== DOM Refs =====
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    // ===== Initialization =====
    function init() {
        if (CONFIG.DEFAULT_PAT) {
            $('#pat-input').value = CONFIG.DEFAULT_PAT;
        }
        serviceToken = CONFIG.SERVICE_PAT || null;

        // Pick up PAT from cross-tab handoff (localStorage), then clean up
        const handoffPat = localStorage.getItem('ghes_pat_handoff');
        if (handoffPat) {
            localStorage.removeItem('ghes_pat_handoff');
            sessionStorage.setItem('ghes_pat', handoffPat);
        }

        token = sessionStorage.getItem('ghes_pat');
        if (token) {
            authenticate();
        } else {
            showLogin();
        }
        bindEvents();
        ReviewStore.open().catch(() => {});
    }

    function bindEvents() {
        $('#login-form').addEventListener('submit', handleLogin);
        $('#logout-btn').addEventListener('click', handleLogout);
        $('#repo-search').addEventListener('input', handleRepoSearch);
        $('#repo-search').addEventListener('keydown', handleSearchKeydown);
        $('#repo-search').addEventListener('focus', () => openDropdown());
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.repo-search-wrapper')) closeDropdown();
        });
        $('#back-to-prs').addEventListener('click', showPRList);
        $('#run-ai-review').addEventListener('click', runAIReview);
        $('#pr-filter').addEventListener('input', handlePRFilter);
        $('#follow-up-btn').addEventListener('click', handleFollowUp);
        $('#follow-up-input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') handleFollowUp();
        });
        const toggleInlineBtn = $('#toggle-inline-comments');
        if (toggleInlineBtn) toggleInlineBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleInlineCommentsVisibility();
        });

        // Collapse related PRs sidebar
        const collapseRelatedBtn = $('#collapse-related-prs');
        if (collapseRelatedBtn) collapseRelatedBtn.addEventListener('click', () => {
            $('#related-prs-sidebar').classList.add('hidden');
        });

        // Post to GitHub
        const postBtn = $('#post-to-github');
        if (postBtn) postBtn.addEventListener('click', () => showConfirmDialog());

        // Confirm dialog
        const confirmCancel = $('#confirm-cancel');
        if (confirmCancel) confirmCancel.addEventListener('click', hideConfirmDialog);
        const confirmOk = $('#confirm-ok');
        if (confirmOk) confirmOk.addEventListener('click', () => {
            hideConfirmDialog();
            postToGitHub();
        });
    }

    // ===== Confirm Dialog =====
    function showConfirmDialog() {
        $('#confirm-overlay').classList.remove('hidden');
    }
    function hideConfirmDialog() {
        $('#confirm-overlay').classList.add('hidden');
    }

    // ===== Authentication =====
    async function handleLogin(e) {
        e.preventDefault();
        const pat = $('#pat-input').value.trim();
        if (!pat) return;

        token = pat;
        $('#login-btn').disabled = true;
        $('#login-btn').innerHTML = '<span class="spinner"></span> Signing in...';

        try {
            await authenticate();
        } catch (err) {
            token = null;
            sessionStorage.removeItem('ghes_pat');
            showLogin();
            showToast(err.message, 'error');
        } finally {
            $('#login-btn').disabled = false;
            $('#login-btn').textContent = 'Sign in';
        }
    }

    async function authenticate() {
        currentUser = await apiGet('/user', token);
        if (!currentUser || !currentUser.login) {
            throw new Error('Invalid token — could not authenticate.');
        }

        sessionStorage.setItem('ghes_pat', token);
        showApp();
        loadRepos();

        // Auto-open a PR if URL has ?repo=owner/name&pr=123
        checkDeepLink();

        // Check access in background
        let isMember = false;

        if (Array.isArray(CONFIG.ACCESS_USERS) &&
            CONFIG.ACCESS_USERS.some(u => u.toLowerCase() === currentUser.login.toLowerCase())) {
            isMember = true;
        }

        if (!isMember) {
            const teamChecks = CONFIG.ACCESS_TEAM_SLUGS.map(teamSlug =>
                apiGet(
                    `/orgs/${encodeURIComponent(CONFIG.ACCESS_ORG)}/teams/${encodeURIComponent(teamSlug)}/memberships/${encodeURIComponent(currentUser.login)}`
                ).then(membership => ({ status: 'ok', membership }))
                 .catch(err => ({ status: 'error', err }))
            );

            const results = await Promise.all(teamChecks);
            let got403 = false;

            for (const result of results) {
                if (result.status === 'ok' && result.membership && result.membership.state === 'active') {
                    isMember = true;
                    break;
                }
                if (result.status === 'error' && result.err.status === 403) {
                    got403 = true;
                }
            }

            if (got403 && !isMember) {
                throw new Error(
                    serviceToken
                        ? 'Service token configuration error: the SERVICE_PAT is missing the "read:org" scope.'
                        : `Your PAT is missing the "read:org" scope. Please create a new token with scopes: ${CONFIG.REQUIRED_SCOPES_DESCRIPTION}`
                );
            }
        }

        if (!isMember) {
            token = null;
            sessionStorage.removeItem('ghes_pat');
            sessionStorage.removeItem(REPO_CACHE_KEY);
            repos = [];
            selectedRepo = null;
            showAccessDenied();
        }
    }

    function handleLogout() {
        token = null;
        currentUser = null;
        repos = [];
        selectedRepo = null;
        prs = [];
        currentPR = null;
        currentDiff = '';
        parsedDiffCache = { raw: '', files: [] };
        auditBranchVerified = false;
        sessionStorage.removeItem('ghes_pat');
        sessionStorage.removeItem(REPO_CACHE_KEY);
        showLogin();
    }

    // ===== API Helpers =====
    async function apiGet(path, authToken) {
        authToken = authToken || serviceToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
            },
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.json();
    }

    async function apiGetRaw(path, authToken) {
        authToken = authToken || serviceToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            headers: {
                'Accept': 'application/vnd.github.v3.diff',
                'Authorization': `Bearer ${authToken}`,
            },
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.text();
    }

    async function apiPost(path, body, authToken) {
        authToken = authToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            method: 'POST',
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.json();
    }

    async function apiPut(path, body, authToken) {
        authToken = authToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            method: 'PUT',
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.json();
    }

    async function apiDeleteFile(path, body, authToken) {
        authToken = authToken || token;
        const res = await fetch(`${CONFIG.API_BASE}${path}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        return res.json();
    }

    async function apiGetPage(path, page, authToken) {
        authToken = authToken || serviceToken || token;
        const separator = path.includes('?') ? '&' : '?';
        const res = await fetch(`${CONFIG.API_BASE}${path}${separator}per_page=100&page=${page}`, {
            headers: {
                'Accept': 'application/vnd.github+json',
                'Authorization': `Bearer ${authToken}`,
            },
        });
        if (!res.ok) {
            const err = new Error(`API error: ${res.status}`);
            err.status = res.status;
            throw err;
        }
        const data = await res.json();
        return { data: Array.isArray(data) ? data : [], hasMore: Array.isArray(data) && data.length === 100 };
    }

    // ===== Most Used Repos =====
    const MOST_USED_KEY = 'pr_reviewer_most_used_repos';
    const MOST_USED_MAX = 5;

    function getMostUsedRepos() {
        try {
            const raw = localStorage.getItem(MOST_USED_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch { return []; }
    }

    function trackRepoUsage(repo) {
        const list = getMostUsedRepos();
        const existing = list.find(r => r.full_name === repo.full_name);
        if (existing) {
            existing.count++;
        } else {
            list.push({ full_name: repo.full_name, owner_login: repo.owner.login, name: repo.name, count: 1 });
        }
        list.sort((a, b) => b.count - a.count);
        localStorage.setItem(MOST_USED_KEY, JSON.stringify(list.slice(0, MOST_USED_MAX)));
    }

    function renderMostUsedRepos() {
        const container = $('#most-used-repos');
        const listEl = $('#most-used-list');
        const mostUsed = getMostUsedRepos();
        if (mostUsed.length === 0) {
            container.classList.add('hidden');
            return;
        }
        container.classList.remove('hidden');
        listEl.innerHTML = '';
        mostUsed.forEach(item => {
            const chip = document.createElement('button');
            chip.className = 'most-used-chip';
            chip.textContent = item.full_name;
            chip.addEventListener('click', () => {
                const repo = repos.find(r => r.full_name === item.full_name);
                if (repo) {
                    selectRepo(repo);
                } else {
                    selectRepo({ full_name: item.full_name, owner: { login: item.owner_login }, name: item.name });
                }
            });
            listEl.appendChild(chip);
        });
    }

    // ===== Repository Loading =====
    let reposLoading = false;
    let highlightIndex = -1;
    let filteredRepos = [];
    let searchDebounceTimer = null;
    const REPO_CACHE_KEY = 'pr_reviewer_repos_cache';
    const REPO_CACHE_TTL = 5 * 60 * 1000;

    function getCachedRepos() {
        try {
            const raw = sessionStorage.getItem(REPO_CACHE_KEY);
            if (!raw) return null;
            const cached = JSON.parse(raw);
            if (Date.now() - cached.ts > REPO_CACHE_TTL) {
                sessionStorage.removeItem(REPO_CACHE_KEY);
                return null;
            }
            return cached.data;
        } catch { return null; }
    }

    function setCachedRepos(data) {
        try {
            sessionStorage.setItem(REPO_CACHE_KEY, JSON.stringify({ ts: Date.now(), data }));
        } catch { /* storage full */ }
    }

    async function loadRepos() {
        showReposLoading();
        reposLoading = true;
        repos = [];

        const cached = getCachedRepos();
        if (cached && cached.length > 0) {
            repos = cached;
            repos.sort((a, b) => a.full_name.localeCompare(b.full_name));
            reposLoading = false;
            updateRepoCount();
            renderRepoDropdown(repos);
            fetchAllRepos(true);
            return;
        }

        await fetchAllRepos(false);
    }

    async function fetchAllRepos(silent) {
        if (!silent) reposLoading = true;
        try {
            const firstPageData = await apiGetPage('/user/repos?sort=full_name', 1, token);
            if (!silent) {
                repos = firstPageData.data;
                repos.sort((a, b) => a.full_name.localeCompare(b.full_name));
                updateRepoCount();
                renderRepoDropdown(repos);
            }

            let allData = firstPageData.data;
            if (firstPageData.hasMore) {
                const pagePromises = [];
                for (let page = 2; page <= 20; page++) {
                    pagePromises.push(apiGetPage('/user/repos?sort=full_name', page, token));
                }
                const results = await Promise.allSettled(pagePromises);
                for (const result of results) {
                    if (result.status === 'fulfilled' && result.value.data.length > 0) {
                        allData = allData.concat(result.value.data);
                    }
                }
            }

            allData.sort((a, b) => a.full_name.localeCompare(b.full_name));
            repos = allData;
            setCachedRepos(allData);
            updateRepoCount();

            const query = $('#repo-search').value.toLowerCase().trim();
            if (query) {
                handleRepoSearch();
            } else {
                renderRepoDropdown(repos);
            }
        } catch (err) {
            if (!silent) showToast('Failed to load repositories: ' + err.message, 'error');
        } finally {
            reposLoading = false;
        }
    }

    function updateRepoCount() {
        const countEl = $('#repo-count');
        countEl.textContent = reposLoading
            ? `${repos.length} repositories loaded (still fetching...)`
            : `${repos.length} repositories`;
    }

    function renderRepoDropdown(list) {
        filteredRepos = list;
        highlightIndex = -1;
        const dropdown = $('#repo-dropdown');
        const query = $('#repo-search').value.toLowerCase().trim();

        if (reposLoading && list.length === 0) {
            dropdown.innerHTML = `
                <div class="repo-dropdown-shimmer">
                    <div class="shimmer-line"></div>
                    <div class="shimmer-line"></div>
                    <div class="shimmer-line"></div>
                </div>`;
            return;
        }

        if (list.length === 0) {
            dropdown.innerHTML = `
                <div class="repo-dropdown-empty">
                    <span>No repositories match "${escapeHtml(query)}"</span>
                </div>`;
            return;
        }

        const visibleItems = list.slice(0, 50);
        const fragment = document.createDocumentFragment();

        visibleItems.forEach((repo, idx) => {
            const item = document.createElement('div');
            item.className = 'repo-dropdown-item';
            item.dataset.index = idx;
            item.innerHTML = highlightMatch(repo, query);
            item.addEventListener('click', () => selectRepo(repo));
            fragment.appendChild(item);
        });

        if (list.length > 50) {
            const more = document.createElement('div');
            more.className = 'repo-dropdown-more';
            more.textContent = `+ ${list.length - 50} more — type to narrow results`;
            fragment.appendChild(more);
        }

        dropdown.innerHTML = '';
        dropdown.appendChild(fragment);
    }

    function highlightMatch(repo, query) {
        const owner = escapeHtml(repo.owner.login);
        const name = escapeHtml(repo.name);
        if (!query) return `<span class="repo-owner">${owner} / </span>${name}`;

        const displayFull = `${owner} / ${name}`;
        const dIdx = displayFull.toLowerCase().indexOf(query);
        if (dIdx === -1) return `<span class="repo-owner">${owner} / </span>${name}`;

        const before = displayFull.slice(0, dIdx);
        const match = displayFull.slice(dIdx, dIdx + query.length);
        const after = displayFull.slice(dIdx + query.length);
        return `${before}<mark class="search-highlight">${match}</mark>${after}`;
    }

    function handleRepoSearch() {
        clearTimeout(searchDebounceTimer);
        searchDebounceTimer = setTimeout(() => {
            const query = $('#repo-search').value.toLowerCase().trim();
            const filtered = query
                ? repos.filter(r => r.full_name.toLowerCase().includes(query))
                : repos;
            renderRepoDropdown(filtered);
            openDropdown();
        }, 120);
    }

    function handleSearchKeydown(e) {
        const dropdown = $('#repo-dropdown');
        if (!dropdown.classList.contains('open')) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            highlightIndex = Math.min(highlightIndex + 1, Math.min(filteredRepos.length - 1, 49));
            updateHighlight();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            highlightIndex = Math.max(highlightIndex - 1, 0);
            updateHighlight();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightIndex >= 0 && highlightIndex < filteredRepos.length) {
                selectRepo(filteredRepos[highlightIndex]);
            }
        } else if (e.key === 'Escape') {
            closeDropdown();
            $('#repo-search').blur();
        }
    }

    function updateHighlight() {
        const dropdown = $('#repo-dropdown');
        dropdown.querySelectorAll('.repo-dropdown-item').forEach((item, idx) => {
            item.classList.toggle('highlighted', idx === highlightIndex);
        });
        const highlighted = dropdown.querySelector('.repo-dropdown-item.highlighted');
        if (highlighted) highlighted.scrollIntoView({ block: 'nearest' });
    }

    function openDropdown() { $('#repo-dropdown').classList.add('open'); }
    function closeDropdown() { $('#repo-dropdown').classList.remove('open'); highlightIndex = -1; }

    function selectRepo(repo) {
        selectedRepo = repo;
        $('#repo-search').value = repo.full_name;
        closeDropdown();
        trackRepoUsage(repo);
        renderMostUsedRepos();
        loadPullRequests();
    }

    function showReposLoading() {
        $('#repo-count').textContent = 'Loading repositories...';
    }

    // ===== Pull Requests =====
    async function loadPullRequests() {
        if (!selectedRepo) return;

        const section = $('#pr-section');
        section.classList.remove('hidden');
        $('#review-panel').classList.add('hidden');
        $('#pr-table').classList.add('hidden');
        $('#pr-empty').classList.add('hidden');
        $('#pr-loading').classList.remove('hidden');
        $('#pr-filter').value = '';

        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;

        try {
            const authToken = serviceToken || token;
            const data = await apiGet(
                `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls?state=open&per_page=${CONFIG.PRS_PER_PAGE}&sort=updated&direction=desc`,
                authToken
            );
            prs = Array.isArray(data) ? data : [];
            $('#pr-loading').classList.add('hidden');

            if (prs.length === 0) {
                $('#pr-empty').classList.remove('hidden');
                return;
            }

            // Fetch file counts in parallel
            const fileCountPromises = prs.map(pr =>
                apiGet(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${pr.number}`, authToken)
                    .then(detail => ({ number: pr.number, changed_files: detail.changed_files, additions: detail.additions, deletions: detail.deletions }))
                    .catch(() => ({ number: pr.number, changed_files: '?', additions: 0, deletions: 0 }))
            );

            // Render table immediately, update stats as they arrive
            renderPRTable(prs);
            $('#pr-table').classList.remove('hidden');

            const details = await Promise.all(fileCountPromises);
            const detailMap = {};
            details.forEach(d => { detailMap[d.number] = d; });

            // Update stat cells
            $$('.pr-stat-cell').forEach(cell => {
                const prNum = parseInt(cell.dataset.prNumber, 10);
                const d = detailMap[prNum];
                if (d) {
                    cell.innerHTML = `
                        <span class="pr-stat">${d.changed_files} file${d.changed_files !== 1 ? 's' : ''}</span>
                        <span class="pr-stat-add">+${d.additions}</span>
                        <span class="pr-stat-del">-${d.deletions}</span>`;
                }
            });

        } catch (err) {
            $('#pr-loading').classList.add('hidden');
            showToast('Failed to load pull requests: ' + err.message, 'error');
        }
    }

    function renderPRTable(prList) {
        const tbody = $('#pr-table-body');
        tbody.innerHTML = '';

        const fragment = document.createDocumentFragment();
        prList.forEach(pr => {
            const tr = document.createElement('tr');
            const labelsHtml = (pr.labels || []).map(l => {
                const bg = l.color ? `#${l.color}` : '#30363d';
                const textColor = isLightColor(l.color) ? '#000' : '#fff';
                return `<span class="pr-label" style="background:${bg};color:${textColor};border-color:${bg}">${escapeHtml(l.name)}</span>`;
            }).join('');

            tr.innerHTML = `
                <td class="pr-title-cell">
                    <a class="pr-title-link" data-pr-number="${pr.number}">${escapeHtml(pr.title)}</a>
                    <span class="pr-number">#${pr.number}</span>
                    ${labelsHtml ? `<div class="pr-labels">${labelsHtml}</div>` : ''}
                </td>
                <td>
                    <span class="pr-author">${escapeHtml(pr.user ? pr.user.login : 'unknown')}</span>
                </td>
                <td>
                    <span class="pr-branch" title="${escapeHtml(pr.head.ref)} → ${escapeHtml(pr.base.ref)}">${escapeHtml(pr.head.ref)}</span>
                </td>
                <td class="pr-stat-cell" data-pr-number="${pr.number}">
                    <span class="pr-stat" style="opacity:0.5">Loading...</span>
                </td>
                <td>
                    <span class="pr-time">${timeAgo(pr.updated_at)}</span>
                </td>
                <td>
                    <button class="btn btn-ai btn-sm" data-pr-number="${pr.number}">
                        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"/>
                        </svg>
                        Review
                    </button>
                </td>
            `;
            fragment.appendChild(tr);
        });
        tbody.appendChild(fragment);

        // Event delegation for review buttons and title links
        if (!tbody.dataset.delegated) {
            tbody.addEventListener('click', (e) => {
                const btn = e.target.closest('[data-pr-number]');
                if (!btn) return;
                const prNum = parseInt(btn.dataset.prNumber, 10);
                const pr = prs.find(p => p.number === prNum);
                if (pr) openReview(pr);
            });
            tbody.dataset.delegated = '1';
        }
    }

    function handlePRFilter() {
        const query = $('#pr-filter').value.toLowerCase().trim();
        if (!query) {
            renderPRTable(prs);
            return;
        }
        const filtered = prs.filter(pr =>
            pr.title.toLowerCase().includes(query) ||
            String(pr.number).includes(query) ||
            (pr.user && pr.user.login.toLowerCase().includes(query)) ||
            pr.head.ref.toLowerCase().includes(query)
        );
        renderPRTable(filtered);
    }

    // ===== Review Panel =====
    async function openReview(pr) {
        currentPR = pr;
        currentDiff = '';

        // Switch views
        $('#pr-section').classList.add('hidden');
        const panel = $('#review-panel');
        panel.classList.remove('hidden');

        // Header
        $('#review-pr-title').textContent = `${pr.title} #${pr.number}`;
        $('#review-meta').innerHTML = `
            <span>by <strong>${escapeHtml(pr.user ? pr.user.login : 'unknown')}</strong></span>
            <span>${escapeHtml(pr.head.ref)} → ${escapeHtml(pr.base.ref)}</span>
            <span>Updated ${timeAgo(pr.updated_at)}</span>
            <a href="${escapeHtml(pr.html_url)}" target="_blank" rel="noopener" style="color:var(--color-primary)">Open on GitHub ↗</a>
        `;

        // Body
        $('#review-body').textContent = pr.body || '(No description provided)';

        // Reset AI review section
        $('#ai-review-result').classList.add('hidden');
        $('#ai-review-result').innerHTML = '';
        $('#ai-review-loading').classList.add('hidden');
        $('#run-ai-review').disabled = false;
        $('#follow-up-section').classList.add('hidden');
        $('#post-to-github').classList.add('hidden');
        $('#ai-summary-section').style.display = 'none';
        conversationMessages = [];
        inlineComments = [];
        inlineCommentsVisible = true;
        $$('.diff-inline-comment, .inline-ask-row').forEach(el => el.remove());
        const toggleBtn = $('#toggle-inline-comments');
        if (toggleBtn) { toggleBtn.classList.add('hidden'); toggleBtn.textContent = 'Hide Comments'; }

        // Load past reviews, diff, and related PRs in parallel
        const [savedReviews] = await Promise.all([
            loadPastReviews(pr),
            loadDiff(pr),
        ]);

        // Fetch related PRs (non-blocking — runs in background)
        fetchRelatedPRs(pr);

        // Check PR approval in background (non-blocking)
        checkPRApprovalAndCleanup(pr);

        // Smart cache: check if latest review matches current head commit
        const aiReviewBtn = $('#run-ai-review');
        const aiConfigured = CONFIG.AI_ENDPOINT && CONFIG.AI_API_KEY;

        if (savedReviews && savedReviews.length > 0) {
            const latest = savedReviews[0]; // sorted desc by timestamp
            if (latest.headSha && latest.headSha === pr.head.sha) {
                // No new commits — auto-load the cached review
                const comments = extractInlineComments(latest.review);
                const cleanContent = stripInlineCommentsBlock(latest.review);
                $('#ai-review-result').innerHTML = renderMarkdown(cleanContent);
                $('#ai-review-result').classList.remove('hidden');
                $('#ai-summary-section').style.display = '';
                $('#post-to-github').classList.remove('hidden');
                annotateInlineComments(comments);
                if (latest.messages && latest.messages.length > 0) {
                    conversationMessages = latest.messages;
                    $('#follow-up-section').classList.remove('hidden');
                }
                aiReviewBtn.disabled = true;
                aiReviewBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"/></svg> AI Review (up to date)`;
                $('#ai-hint').textContent = 'Review loaded from audit-data — no new commits detected.';
                $('#ai-hint').classList.remove('hidden');
            } else {
                // New commits since last review
                aiReviewBtn.disabled = false;
                $('#ai-hint').textContent = 'New commits detected since last review — click AI Review to re-analyze.';
                $('#ai-hint').classList.remove('hidden');
            }
        } else {
            // No saved reviews — first-time
            if (!aiConfigured) {
                $('#ai-hint').textContent = 'AI endpoint not configured in config.js.';
                $('#ai-hint').classList.remove('hidden');
                aiReviewBtn.disabled = true;
            } else {
                $('#ai-hint').classList.add('hidden');
            }
        }
    }

    // ===== Related PRs (same title across org repos) =====
    async function fetchRelatedPRs(pr) {
        const sidebar = $('#related-prs-sidebar');
        const loading = $('#related-prs-loading');
        const emptyEl = $('#related-prs-empty');
        const listEl = $('#related-prs-list');
        const countEl = $('#related-prs-count');

        // Reset & show sidebar
        sidebar.classList.remove('hidden');
        loading.classList.remove('hidden');
        emptyEl.classList.add('hidden');
        listEl.innerHTML = '';
        countEl.classList.add('hidden');

        try {
            const authToken = serviceToken || token;
            const org = CONFIG.ACCESS_ORG;
            const title = pr.title;
            // GitHub Search API: exact title match, open PRs, org-scoped
            const q = encodeURIComponent(`type:pr state:open org:${org} in:title "${title}"`);
            const data = await apiGet(`/search/issues?q=${q}&per_page=50`, authToken);
            const items = (data && data.items) || [];

            // Filter out the current PR (same repo + same number)
            const currentRepoFullName = selectedRepo.full_name.toLowerCase();
            const related = items.filter(item => {
                // item.repository_url ends with /repos/{owner}/{repo}
                const repoUrl = (item.repository_url || '').toLowerCase();
                const repoFullName = repoUrl.split('/repos/').pop() || '';
                return !(repoFullName === currentRepoFullName && item.number === pr.number);
            });

            loading.classList.add('hidden');

            if (related.length === 0) {
                emptyEl.classList.remove('hidden');
                return;
            }

            countEl.textContent = related.length;
            countEl.classList.remove('hidden');
            renderRelatedPRs(related);
        } catch (err) {
            loading.classList.add('hidden');
            emptyEl.textContent = 'Failed to search related PRs.';
            emptyEl.classList.remove('hidden');
        }
    }

    function renderRelatedPRs(items) {
        const listEl = $('#related-prs-list');
        listEl.innerHTML = '';

        // Group by repo name
        const groups = {};
        items.forEach(item => {
            const repoUrl = item.repository_url || '';
            const repoFullName = repoUrl.split('/repos/').pop() || 'unknown';
            const repoShort = repoFullName.split('/').pop() || repoFullName;
            if (!groups[repoShort]) groups[repoShort] = { fullName: repoFullName, items: [] };
            groups[repoShort].items.push(item);
        });

        Object.keys(groups).sort().forEach(repoName => {
            const group = groups[repoName];
            const groupEl = document.createElement('div');
            groupEl.className = 'related-prs-group';

            const headerEl = document.createElement('div');
            headerEl.className = 'related-prs-repo-name';
            headerEl.textContent = repoName;
            groupEl.appendChild(headerEl);

            group.items.forEach(item => {
                const card = document.createElement('div');
                card.className = 'related-pr-card';
                card.title = 'Open in AI PR Reviewer';
                card.innerHTML = `
                    <span class="related-pr-number">#${item.number}</span>
                    <span class="related-pr-author">${escapeHtml(item.user ? item.user.login : 'unknown')}</span>
                    <span class="related-pr-state related-pr-state--${item.state}">${item.state}</span>
                    <svg class="related-pr-open-icon" width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"/></svg>
                `;
                card.addEventListener('click', () => {
                    openRelatedPR(group.fullName, item.number);
                });
                groupEl.appendChild(card);
            });

            listEl.appendChild(groupEl);
        });
    }

    async function openRelatedPR(repoFullName, prNumber) {
        // Stash PAT in localStorage so the new tab can pick it up
        if (token) localStorage.setItem('ghes_pat_handoff', token);
        // Open in a new tab with query params — the new tab will auto-navigate to the PR review
        const url = `${window.location.pathname}?repo=${encodeURIComponent(repoFullName)}&pr=${encodeURIComponent(prNumber)}`;
        window.open(url, '_blank');
    }

    function resetRelatedPRsSidebar() {
        const sidebar = $('#related-prs-sidebar');
        if (sidebar) {
            sidebar.classList.add('hidden');
            $('#related-prs-loading').classList.add('hidden');
            $('#related-prs-empty').classList.add('hidden');
            $('#related-prs-list').innerHTML = '';
            $('#related-prs-count').classList.add('hidden');
        }
    }

    async function checkDeepLink() {
        const params = new URLSearchParams(window.location.search);
        const repoParam = params.get('repo');
        const prParam = params.get('pr');
        if (!repoParam || !prParam) return;

        // Clear the URL params so refreshing doesn't re-trigger
        window.history.replaceState({}, '', window.location.pathname);

        try {
            const authToken = serviceToken || token;
            const [owner, name] = repoParam.split('/');
            if (!owner || !name) return;

            // Fetch repo info and PR data in parallel
            const [repoData, prData] = await Promise.all([
                apiGet(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`, authToken),
                apiGet(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${encodeURIComponent(prParam)}`, authToken),
            ]);

            selectedRepo = repoData;
            $('#repo-search').value = repoData.full_name;
            openReview(prData);
        } catch (err) {
            showToast('Failed to open linked PR: ' + err.message, 'error');
        }
    }

    function showPRList() {
        $('#review-panel').classList.add('hidden');
        $('#pr-section').classList.remove('hidden');
        currentPR = null;
        currentDiff = '';
        resetRelatedPRsSidebar();
    }

    async function loadPastReviews(pr) {
        const container = $('#past-reviews');
        const list = $('#past-reviews-list');
        if (!container || !list) return [];

        try {
            const reviews = await ReviewStore.getReviews(selectedRepo.full_name, pr.number);
            if (reviews.length === 0) {
                container.classList.add('hidden');
                return [];
            }
            container.classList.remove('hidden');
            // Show the AI summary section so past reviews are accessible
            $('#ai-summary-section').style.display = '';
            list.innerHTML = '';
            reviews.forEach(r => {
                const item = document.createElement('div');
                item.className = 'past-review-item';
                const preview = (r.review || '').replace(/[#*`\n]/g, ' ').slice(0, 80);
                item.innerHTML = `
                    <span class="past-review-time">${new Date(r.timestamp).toLocaleString()}</span>
                    <span class="past-review-preview">${escapeHtml(preview)}...</span>
                    <button class="btn btn-sm past-review-load">Load</button>
                    <button class="btn btn-sm past-review-delete">Delete</button>
                `;
                item.querySelector('.past-review-load').addEventListener('click', () => {
                    const comments = extractInlineComments(r.review);
                    const cleanContent = stripInlineCommentsBlock(r.review);
                    $('#ai-review-result').innerHTML = renderMarkdown(cleanContent);
                    $('#ai-review-result').classList.remove('hidden');
                    $('#ai-summary-section').style.display = '';
                    $('#post-to-github').classList.remove('hidden');
                    annotateInlineComments(comments);
                    if (r.messages && r.messages.length > 0) {
                        conversationMessages = r.messages;
                        $('#follow-up-section').classList.remove('hidden');
                    }
                });
                item.querySelector('.past-review-delete').addEventListener('click', async () => {
                    try {
                        await ReviewStore.deleteReview(r);
                        item.remove();
                        if (list.children.length === 0) container.classList.add('hidden');
                        showToast('Review deleted from audit-data branch.', 'success');
                    } catch (err) {
                        showToast('Failed to delete review: ' + err.message, 'error');
                    }
                });
                list.appendChild(item);
            });
            return reviews;
        } catch {
            container.classList.add('hidden');
            return [];
        }
    }

    async function checkPRApprovalAndCleanup(pr) {
        if (!selectedRepo) return;
        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;
        try {
            const reviews = await apiGet(
                `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${pr.number}/reviews`,
                token
            );
            const isApproved = Array.isArray(reviews) && reviews.some(r => r.state === 'APPROVED');
            if (isApproved) {
                await ReviewStore.deleteAllReviews(selectedRepo.full_name, pr.number);
                const container = $('#past-reviews');
                if (container) container.classList.add('hidden');
                // Re-enable AI Review button since reviews were cleaned
                const aiReviewBtn = $('#run-ai-review');
                aiReviewBtn.disabled = false;
                aiReviewBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"/></svg> AI Review`;
                $('#ai-hint').textContent = 'PR approved — AI reviews cleaned up from audit-data branch.';
                $('#ai-hint').classList.remove('hidden');
                // Hide the auto-loaded review since it was cleaned
                $('#ai-review-result').classList.add('hidden');
                $('#ai-review-result').innerHTML = '';
                $('#ai-summary-section').style.display = 'none';
                $('#post-to-github').classList.add('hidden');
                $('#follow-up-section').classList.add('hidden');
                showToast('PR approved — AI reviews cleaned up.', 'success');
            }
        } catch { /* best effort — don't block PR view */ }
    }

    async function loadDiff(pr) {
        const container = $('#diff-container');
        const loading = $('#diff-loading');
        loading.classList.remove('hidden');
        container.querySelectorAll('.diff-file').forEach(el => el.remove());

        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;

        try {
            const authToken = serviceToken || token;
            const diff = await apiGetRaw(
                `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${pr.number}`,
                authToken
            );
            currentDiff = diff;
            loading.classList.add('hidden');
            renderDiff(diff);
        } catch (err) {
            loading.classList.add('hidden');
            container.innerHTML = `<div class="empty-state"><p>Failed to load diff: ${escapeHtml(err.message)}</p></div>`;
        }
    }

    function renderDiff(diff) {
        const container = $('#diff-container');
        // Remove old file elements, keep loading overlay
        container.querySelectorAll('.diff-file').forEach(el => el.remove());

        const files = parseDiff(diff);
        $('#diff-file-count').textContent = `(${files.length} file${files.length !== 1 ? 's' : ''})`;

        if (files.length === 0) {
            container.innerHTML += '<div class="empty-state"><p>No file changes found in this diff.</p></div>';
            return;
        }

        const fragment = document.createDocumentFragment();
        files.forEach(file => {
            const fileEl = document.createElement('div');
            fileEl.className = 'diff-file';

            // Count additions/deletions in single pass
            let additions = 0, deletions = 0;
            for (const l of file.lines) {
                if (l.type === 'add') additions++;
                else if (l.type === 'del') deletions++;
            }

            let headerHtml = `
                <div class="diff-file-header" data-toggle="diff">
                    <span>${escapeHtml(file.name)}</span>
                    <span class="diff-stat">
                        <span class="pr-stat-add">+${additions}</span>
                        <span class="pr-stat-del">-${deletions}</span>
                    </span>
                </div>
            `;

            let tableHtml = '<div class="diff-file-content"><table class="diff-table"><tbody>';
            for (const line of file.lines) {
                const cls = line.type === 'add' ? 'diff-line-add'
                          : line.type === 'del' ? 'diff-line-del'
                          : line.type === 'hunk' ? 'diff-line-hunk'
                          : '';
                if (line.type === 'hunk') {
                    tableHtml += `<tr class="${cls}"><td colspan="3">${escapeHtml(line.content)}</td></tr>`;
                } else {
                    tableHtml += `<tr class="${cls}"><td class="diff-line-num">${line.oldNum || ''}</td><td class="diff-line-num">${line.newNum || ''}</td><td>${escapeHtml(line.content)}</td></tr>`;
                }
            }
            tableHtml += '</tbody></table></div>';

            fileEl.innerHTML = headerHtml + tableHtml;
            fragment.appendChild(fileEl);

            // Toggle collapse
            fileEl.querySelector('.diff-file-header').addEventListener('click', () => {
                const content = fileEl.querySelector('.diff-file-content');
                content.style.display = content.style.display === 'none' ? '' : 'none';
            });
        });
        container.appendChild(fragment);
    }

    function parseDiff(diff) {
        // Return cached result if diff hasn't changed
        if (parsedDiffCache.raw === diff) return parsedDiffCache.files;

        const files = [];
        const fileChunks = diff.split(/^diff --git /m).filter(Boolean);

        fileChunks.forEach(chunk => {
            const lines = chunk.split('\n');
            // Extract filename from the first line: a/path b/path
            const firstLine = lines[0] || '';
            const nameMatch = firstLine.match(/b\/(.+)$/);
            const name = nameMatch ? nameMatch[1] : firstLine;

            const parsedLines = [];
            let oldLine = 0;
            let newLine = 0;

            lines.forEach(line => {
                if (line.startsWith('@@')) {
                    const hunkMatch = line.match(/@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
                    if (hunkMatch) {
                        oldLine = parseInt(hunkMatch[1], 10);
                        newLine = parseInt(hunkMatch[2], 10);
                    }
                    parsedLines.push({ type: 'hunk', content: line, oldNum: '', newNum: '' });
                } else if (line.startsWith('+') && !line.startsWith('+++')) {
                    parsedLines.push({ type: 'add', content: line.slice(1), oldNum: '', newNum: newLine });
                    newLine++;
                } else if (line.startsWith('-') && !line.startsWith('---')) {
                    parsedLines.push({ type: 'del', content: line.slice(1), oldNum: oldLine, newNum: '' });
                    oldLine++;
                } else if (!line.startsWith('\\') && !line.startsWith('diff') && !line.startsWith('index') && !line.startsWith('---') && !line.startsWith('+++') && !line.startsWith('new file') && !line.startsWith('deleted file') && !line.startsWith('old mode') && !line.startsWith('new mode') && !line.startsWith('similarity') && !line.startsWith('rename') && !line.startsWith('Binary')) {
                    if (line !== '' || parsedLines.length > 0) {
                        parsedLines.push({ type: 'context', content: line.startsWith(' ') ? line.slice(1) : line, oldNum: oldLine, newNum: newLine });
                        oldLine++;
                        newLine++;
                    }
                }
            });

            if (parsedLines.length > 0) {
                files.push({ name, lines: parsedLines });
            }
        });

        parsedDiffCache = { raw: diff, files };
        return files;
    }

    // ===== AI Helper =====
    function getAIEndpointCandidates() {
        const raw = String(CONFIG.AI_ENDPOINT || '').trim();
        if (!raw) return [];

        let parsed;
        try {
            parsed = new URL(raw);
        } catch {
            return [raw];
        }

        const currentPath = parsed.pathname || '/';
        const hasLikelyAIPath = /chat\/completions|responses|openai\//i.test(currentPath);
        if (hasLikelyAIPath) {
            return [parsed.toString()];
        }

        const base = `${parsed.origin}${currentPath.replace(/\/$/, '')}`;
        const fallbacks = [
            '/v1/chat/completions',
            '/openai/v1/chat/completions',
            '/api/v1/chat/completions',
            '/chat/completions',
            '/v1/responses',
        ];

        const candidates = [parsed.toString()];
        for (const suffix of fallbacks) {
            candidates.push(`${base}${suffix}`);
        }
        return [...new Set(candidates)];
    }

    function extractAIContent(data) {
        if (!data || typeof data !== 'object') return null;

        const responseOutputText = data.output_text;
        if (typeof responseOutputText === 'string' && responseOutputText.trim()) {
            return responseOutputText;
        }

        const outputItems = Array.isArray(data.output) ? data.output : [];
        for (const item of outputItems) {
            const contentParts = Array.isArray(item?.content) ? item.content : [];
            for (const part of contentParts) {
                const text = part?.text || part?.value;
                if (typeof text === 'string' && text.trim()) {
                    return text;
                }
            }
        }

        return data.choices?.[0]?.message?.content
            || data.choices?.[0]?.text
            || data.message?.content
            || data.output?.choices?.[0]?.message?.content
            || data.result
            || data.response
            || (typeof data.output === 'string' ? data.output : null)
            || null;
    }

    async function callAI(messages, onChunk) {
        const endpoints = getAIEndpointCandidates();
        if (!endpoints.length) {
            throw new Error('AI endpoint not configured. Set AI_ENDPOINT in config.js.');
        }

        const useStreaming = typeof onChunk === 'function';

        const payload = {
            model: CONFIG.AI_MODEL,
            messages,
            max_completion_tokens: CONFIG.AI_MAX_TOKENS,
            stream: useStreaming,
        };
        if (typeof CONFIG.AI_TEMPERATURE === 'number') {
            payload.temperature = CONFIG.AI_TEMPERATURE;
        }

        let lastError = null;

        for (let i = 0; i < endpoints.length; i++) {
            const endpoint = endpoints[i];
            let response;

            try {
                response = await fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${CONFIG.AI_API_KEY}`,
                        'x-api-key': CONFIG.AI_API_KEY,
                    },
                    body: JSON.stringify(payload),
                });
            } catch (networkErr) {
                lastError = new Error(`Network error calling AI endpoint ${endpoint}: ${networkErr.message}`);
                continue;
            }

            if (!response.ok) {
                const errText = await response.text().catch(() => '');
                lastError = new Error(`AI API error ${response.status} at ${endpoint}: ${errText.slice(0, 300)}`);

                // Try fallback endpoint for route/method mismatches.
                if ((response.status === 404 || response.status === 405) && i < endpoints.length - 1) {
                    continue;
                }
                throw lastError;
            }

            // Streaming response
            if (useStreaming && response.headers.get('content-type')?.includes('text/event-stream')) {
                const streamedContent = await readSSEStream(response, onChunk);
                if (streamedContent) return streamedContent;
                // If streaming returned empty, the format was unrecognized — fall through won't work
                // since response body is consumed; throw so caller retries without streaming
                console.warn('SSE stream returned empty content — endpoint may not support streaming format.');
                throw new Error('Streaming returned empty response. Retrying without streaming.');
            }

            // If streaming was requested but server didn't return SSE, fall back to normal parsing
            const data = await response.json();
            console.log('AI response:', JSON.stringify(data).slice(0, 500));

            const content = extractAIContent(data);
            if (!content) {
                throw new Error(`Unexpected AI response format from ${endpoint}. Check browser console for details.`);
            }
            if (useStreaming) onChunk(content, content);
            return content;
        }

        throw lastError || new Error('AI request failed for all configured endpoint candidates.');
    }

    async function readSSEStream(response, onChunk) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullContent = '';
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop(); // keep incomplete line in buffer

            for (const line of lines) {
                const delta = extractSSEDelta(line);
                if (delta) {
                    fullContent += delta;
                    onChunk(delta, fullContent);
                }
            }
        }

        // Process any remaining data left in buffer
        if (buffer.trim()) {
            const delta = extractSSEDelta(buffer);
            if (delta) {
                fullContent += delta;
                onChunk(delta, fullContent);
            }
        }

        return fullContent;
    }

    function extractSSEDelta(line) {
        if (!line.startsWith('data: ')) return '';
        const data = line.slice(6).trim();
        if (data === '[DONE]') return '';

        try {
            const parsed = JSON.parse(data);
            // OpenAI format
            const openaiDelta = parsed.choices?.[0]?.delta?.content
                || parsed.choices?.[0]?.text;
            if (openaiDelta) return openaiDelta;

            // Anthropic/Bedrock format
            if (parsed.type === 'content_block_delta' && parsed.delta?.text) {
                return parsed.delta.text;
            }
            if (parsed.delta?.type === 'text_delta' && parsed.delta?.text) {
                return parsed.delta.text;
            }

            return '';
        } catch { return ''; }
    }

    // ===== Review Persistence (GitHub audit-data branch) =====
    const AUDIT_BRANCH = CONFIG.AUDIT_BRANCH || 'audit-data';
    const AUDIT_OWNER = CONFIG.AUDIT_REPO_OWNER || '';
    const AUDIT_REPO = CONFIG.AUDIT_REPO_NAME || '';
    let auditBranchVerified = false;

    async function ensureAuditBranch() {
        if (auditBranchVerified) return;
        const auditToken = serviceToken || token;
        // Try both /git/ref/ and /git/refs/ (GHES compatibility)
        let branchExists = false;
        for (const refPath of ['git/ref/heads', 'git/refs/heads']) {
            try {
                const data = await apiGet(`/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/${refPath}/${AUDIT_BRANCH}`, auditToken);
                // /git/refs/ may return an array
                if (data && (data.object || (Array.isArray(data) && data.length > 0))) {
                    branchExists = true;
                    break;
                }
            } catch (e) {
                if (e.status === 404) continue;
                throw e;
            }
        }
        if (branchExists) { auditBranchVerified = true; return; }

        // Branch doesn't exist — create from default branch
        const repoInfo = await apiGet(`/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}`, auditToken);
        const defaultBranch = repoInfo.default_branch || 'main';
        let sha = null;
        for (const refPath of ['git/ref/heads', 'git/refs/heads']) {
            try {
                const refData = await apiGet(`/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/${refPath}/${encodeURIComponent(defaultBranch)}`, auditToken);
                sha = refData.object ? refData.object.sha : (Array.isArray(refData) && refData.length > 0 ? refData[0].object.sha : null);
                if (sha) break;
            } catch { continue; }
        }
        if (!sha) throw new Error(`Could not find SHA for default branch '${defaultBranch}'.`);
        await apiPost(`/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/git/refs`, {
            ref: `refs/heads/${AUDIT_BRANCH}`,
            sha: sha,
        }, auditToken);
        auditBranchVerified = true;
    }

    function getReviewDirPath(repoFullName, prNumber) {
        return `ai-reviews/${repoFullName}/pr-${prNumber}`;
    }

    const ReviewStore = (() => {
        async function open() { /* no-op for GitHub-based store */ }

        async function saveReview(repo, prNumber, prTitle, review, messages, headSha) {
            if (!AUDIT_OWNER || !AUDIT_REPO) { console.warn('Audit repo not configured — skipping save.'); return; }
            const auditToken = serviceToken || token;
            const ts = Date.now();
            const filePath = `${getReviewDirPath(repo, prNumber)}/${ts}.json`;
            // Strip large diff content from messages to keep file size manageable
            const lightMessages = (messages || []).map(m => {
                if (m.role === 'user' && m.content && m.content.length > 2000) {
                    return { role: m.role, content: m.content.slice(0, 2000) + '\n\n[...diff truncated for storage...]' };
                }
                return m;
            });
            const data = {
                id: `${repo}#${prNumber}#${ts}`,
                repo, prNumber, prTitle, review,
                messages: lightMessages,
                headSha: headSha || '',
                timestamp: ts,
                reviewer: currentUser ? currentUser.login : 'unknown',
            };
            try {
                const jsonStr = JSON.stringify(data, null, 2);
                const content = btoa(unescape(encodeURIComponent(jsonStr)));
                await ensureAuditBranch();
                await apiPut(
                    `/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/contents/${filePath}`,
                    { message: `AI Review: ${prTitle} #${prNumber}`, content, branch: AUDIT_BRANCH },
                    auditToken
                );
                console.log('Review saved to audit-data:', filePath);
                showToast('Review saved to audit-data branch.', 'success');
            } catch (err) {
                console.error('Failed to save review to audit-data branch:', err);
                showToast('Failed to save to audit-data: ' + err.message, 'error');
            }
        }

        async function getReviews(repo, prNumber) {
            if (!AUDIT_OWNER || !AUDIT_REPO) return [];
            const auditToken = serviceToken || token;
            const dirPath = getReviewDirPath(repo, prNumber);
            try {
                const files = await apiGet(
                    `/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/contents/${dirPath}?ref=${AUDIT_BRANCH}`,
                    auditToken
                );
                if (!Array.isArray(files)) return [];
                const jsonFiles = files.filter(f => f.name.endsWith('.json'));
                // Fetch all review files in parallel
                const results = await Promise.allSettled(
                    jsonFiles.map(file =>
                        apiGet(
                            `/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/contents/${file.path}?ref=${AUDIT_BRANCH}`,
                            auditToken
                        ).then(fileData => {
                            const decoded = decodeURIComponent(escape(atob(fileData.content.replace(/\n/g, ''))));
                            const review = JSON.parse(decoded);
                            review._sha = fileData.sha;
                            review._path = file.path;
                            return review;
                        })
                    )
                );
                const reviews = results
                    .filter(r => r.status === 'fulfilled')
                    .map(r => r.value);
                return reviews.sort((a, b) => b.timestamp - a.timestamp);
            } catch (e) {
                if (e.status === 404) return [];
                console.warn('Failed to load reviews:', e.message);
                return [];
            }
        }

        async function deleteReview(reviewObj) {
            if (!AUDIT_OWNER || !AUDIT_REPO || !reviewObj || !reviewObj._path || !reviewObj._sha) return;
            const auditToken = serviceToken || token;
            await apiDeleteFile(
                `/repos/${encodeURIComponent(AUDIT_OWNER)}/${encodeURIComponent(AUDIT_REPO)}/contents/${reviewObj._path}`,
                { message: `Delete AI Review: ${reviewObj.prTitle || ''} #${reviewObj.prNumber || ''}`, sha: reviewObj._sha, branch: AUDIT_BRANCH },
                auditToken
            );
        }

        async function deleteAllReviews(repo, prNumber) {
            const reviews = await getReviews(repo, prNumber);
            await Promise.allSettled(reviews.map(r => deleteReview(r)));
        }

        return { open, saveReview, getReviews, deleteReview, deleteAllReviews };
    })();

    // ===== Follow-Up =====
    async function handleFollowUp() {
        const input = $('#follow-up-input');
        const question = input.value.trim();
        if (!question) return;

        const btn = $('#follow-up-btn');
        input.value = '';
        btn.disabled = true;

        const resultEl = $('#ai-review-result');
        const pendingId = 'pending-' + Date.now();
        resultEl.innerHTML += `
            <div class="follow-up-separator"></div>
            <div class="follow-up-question">You: ${escapeHtml(question)}</div>
            <div id="${pendingId}" class="follow-up-answer"><em>Thinking...</em></div>
        `;

        conversationMessages.push({ role: 'user', content: question });

        try {
            let streamRenderTimer = null;
            const pendingEl = document.getElementById(pendingId);

            const content = await callAI(conversationMessages, (delta, fullSoFar) => {
                if (streamRenderTimer) return;
                streamRenderTimer = setTimeout(() => {
                    streamRenderTimer = null;
                    if (pendingEl && fullSoFar) {
                        pendingEl.innerHTML = renderMarkdown(fullSoFar);
                    }
                }, 150);
            });

            if (streamRenderTimer) { clearTimeout(streamRenderTimer); streamRenderTimer = null; }
            conversationMessages.push({ role: 'assistant', content });
            if (pendingEl) pendingEl.innerHTML = renderMarkdown(content);

            if (selectedRepo && currentPR) {
                ReviewStore.saveReview(
                    selectedRepo.full_name, currentPR.number,
                    currentPR.title, content, [...conversationMessages],
                    currentPR.head.sha
                ).catch(err => console.error('ReviewStore.saveReview failed:', err));
            }
        } catch (err) {
            const pendingEl = document.getElementById(pendingId);
            if (pendingEl) pendingEl.innerHTML = `<span style="color:var(--color-danger)">Error: ${escapeHtml(err.message)}</span>`;
        } finally {
            btn.disabled = false;
            input.focus();
        }
    }

    // ===== Diff Chunking =====
    function rebuildFileDiff(file) {
        const parts = [`diff --git a/${file.name} b/${file.name}`];
        for (const line of file.lines) {
            if (line.type === 'hunk') parts.push(line.content);
            else if (line.type === 'add') parts.push('+' + line.content);
            else if (line.type === 'del') parts.push('-' + line.content);
            else parts.push(' ' + line.content);
        }
        return parts.join('\n') + '\n';
    }

    async function reviewChunked() {
        const btn = $('#run-ai-review');
        const loadingEl = $('#ai-review-loading');
        const resultEl = $('#ai-review-result');

        btn.disabled = true;
        loadingEl.classList.remove('hidden');
        resultEl.classList.add('hidden');
        resultEl.innerHTML = '';

        const files = parseDiff(currentDiff);
        const chunkSize = CONFIG.CHUNK_SIZE || 60000;

        // Pre-compute file diffs once (avoids rebuilding later)
        const fileDiffs = new Map();
        for (const file of files) {
            fileDiffs.set(file, rebuildFileDiff(file));
        }

        // Group files into chunks
        const chunks = [];
        let currentChunk = [];
        let currentSize = 0;

        for (const file of files) {
            const fileSize = fileDiffs.get(file).length;

            if (fileSize > chunkSize) {
                if (currentChunk.length > 0) { chunks.push(currentChunk); currentChunk = []; currentSize = 0; }
                chunks.push([file]);
                continue;
            }
            if (currentSize + fileSize > chunkSize) {
                chunks.push(currentChunk);
                currentChunk = [file];
                currentSize = fileSize;
            } else {
                currentChunk.push(file);
                currentSize += fileSize;
            }
        }
        if (currentChunk.length > 0) chunks.push(currentChunk);

        const systemPrompt = getSystemPrompt();
        const prTitle = currentPR.title || '';
        const prBody = currentPR.body || '';
        const headBranch = currentPR.head.ref || '';
        const baseBranch = currentPR.base.ref || '';

        const chunkResults = [];
        const concurrency = CONFIG.AI_CHUNK_CONCURRENCY || 3;

        // Process chunks in parallel with concurrency limit
        for (let start = 0; start < chunks.length; start += concurrency) {
            const batch = chunks.slice(start, start + concurrency);
            loadingEl.querySelector('strong').textContent = `Reviewing chunks ${start + 1}–${Math.min(start + concurrency, chunks.length)} of ${chunks.length}...`;
            loadingEl.querySelector('.ai-loading-sub').textContent =
                `Files: ${batch.flatMap(c => c.map(f => f.name)).join(', ').slice(0, 120)}`;

            const batchPromises = batch.map((chunk, batchIdx) => {
                const i = start + batchIdx;
                const chunkDiff = chunk.map(f => fileDiffs.get(f)).join('\n');
                const userPrompt = `PR Title: ${prTitle}\nPR Description: ${prBody}\nBranch: ${headBranch} → ${baseBranch}\n(Chunk ${i + 1} of ${chunks.length})\n\nDiff:\n\`\`\`diff\n${chunkDiff.slice(0, chunkSize)}\n\`\`\``;

                return callAI([
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userPrompt },
                ]).then(content => ({ files: chunk.map(f => f.name), review: content }))
                  .catch(err => ({ files: chunk.map(f => f.name), review: `Error: ${err.message}` }));
            });

            const batchResults = await Promise.all(batchPromises);
            chunkResults.push(...batchResults);
        }

        // Collect inline comments from all chunks before stripping
        let allInlineComments = [];
        chunkResults.forEach(r => {
            const chunkComments = extractInlineComments(r.review);
            allInlineComments = allInlineComments.concat(chunkComments);
            r.review = stripInlineCommentsBlock(r.review);
        });

        // Summary pass (uses clean reviews)
        loadingEl.querySelector('strong').textContent = 'Generating overall summary...';
        loadingEl.querySelector('.ai-loading-sub').textContent = '';

        let combined = chunkResults.map((r, i) =>
            `## Chunk ${i + 1}: ${r.files.join(', ')}\n\n${r.review}`
        ).join('\n\n---\n\n');

        try {
            const summaryPrompt = `You reviewed a large PR in ${chunks.length} chunks. Here are the results:\n\n${combined}\n\nProvide a brief overall summary: total risk level, most critical issues, and top 3 action items.`;
            const summary = await callAI([
                { role: 'system', content: 'You are a code review summarizer. Be concise.' },
                { role: 'user', content: summaryPrompt },
            ]);
            combined = `## Overall Summary\n\n${summary}\n\n---\n\n${combined}`;
        } catch { /* use combined without summary */ }

        loadingEl.classList.add('hidden');
        resultEl.innerHTML = renderMarkdown(combined);
        resultEl.classList.remove('hidden');
        btn.disabled = false;

        // Annotate inline comments on the diff
        annotateInlineComments(allInlineComments);

        conversationMessages = [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `PR: ${prTitle} (${headBranch} → ${baseBranch}). Reviewed in ${chunks.length} chunks.` },
            { role: 'assistant', content: combined },
        ];
        $('#follow-up-section').classList.remove('hidden');
        $('#ai-summary-section').style.display = '';
        $('#post-to-github').classList.remove('hidden');

        if (selectedRepo && currentPR) {
            ReviewStore.saveReview(
                selectedRepo.full_name, currentPR.number,
                currentPR.title, combined, [...conversationMessages],
                currentPR.head.sha
            ).catch(err => console.error('ReviewStore.saveReview failed:', err));
        }
        showToast(`AI review complete! (${chunks.length} chunks)`, 'success');
    }

    function getSystemPrompt() {
        // Build coding standards section if enabled
        let codingStandardsSection = '';
        if (CONFIG.AI_APPLY_CODING_STANDARDS && CONFIG.AI_CODING_STANDARDS) {
            const standards = CONFIG.AI_CODING_STANDARDS;
            const parts = [];
            // Auto-detect which standards to include based on file extensions in the diff
            const diffLower = (currentDiff || '').toLowerCase();
            const hasCS = /\.(cs|csx|csproj)\b/.test(diffLower);
            const hasPML = /\.(pmlfrm|pmlobj|pmlfnc|pmlmac|pmlcmd)\b/.test(diffLower);
            const hasPython = /\.(py|pyw)\b/.test(diffLower);
            const hasJS = /\.(js|ts|jsx|tsx)\b/.test(diffLower);
            const hasJava = /\.java\b/.test(diffLower);

            if (hasCS && standards.CSHARP) parts.push(standards.CSHARP);
            if (hasPML && standards.PML) parts.push(standards.PML);
            if (hasPML && standards.PML_CHECKLIST) parts.push(standards.PML_CHECKLIST);
            if (standards.UDA) parts.push(standards.UDA);

            // Always include general standards if no specific ones matched
            if (parts.length === 0) {
                Object.values(standards).forEach(s => { if (s) parts.push(s); });
            }

            if (parts.length > 0) {
                codingStandardsSection = `\n\n## Coding Standards to Enforce\nYou MUST check every issue against these standards and flag violations as issues with severity WARNING or CRITICAL:\n\n${parts.join('\n\n')}`;
                if (CONFIG.AI_CODING_STANDARDS_URL) {
                    codingStandardsSection += `\n\nFull coding standards reference: ${CONFIG.AI_CODING_STANDARDS_URL}`;
                }
            }
        }

        const todayStr = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

        return `You are a senior staff engineer conducting a thorough, production-grade code review. You have deep expertise in software architecture, security, performance, and maintainability. You will be given a pull request diff and metadata.

Today's date is ${todayStr}. Use this when validating dates in the code (e.g. revision history entries). A date is only "in the future" if it is AFTER ${todayStr}.

Your review must be meticulous — treat this as the final gate before code reaches production. Do NOT gloss over issues. Every line of changed code must be scrutinized.

## Review Methodology
1. **Read the entire diff carefully** — understand the intent and context before commenting.
2. **Trace data flow** — follow variables from input to output; check for unvalidated data, null/undefined references, type mismatches.
3. **Check boundary conditions** — empty arrays, null values, zero-length strings, off-by-one errors, integer overflow.
4. **Evaluate error handling** — are exceptions caught appropriately? Are error messages helpful? Are resources cleaned up?
5. **Assess concurrency safety** — race conditions, shared mutable state, async/await correctness.
6. **Review naming and readability** — are names descriptive? Is the code self-documenting?
7. **Look for logic errors** — incorrect boolean logic, wrong comparison operators, missing negation, unreachable code.
8. **Check for common bugs** — missing break in switch, assignment vs equality, floating-point comparison, string vs number comparison.
${codingStandardsSection}

## Output Structure

### Summary
A 2-3 sentence overview of the PR's purpose, what it changes, and the overall quality assessment.

### Risk Assessment
Rate overall risk: **LOW** / **MEDIUM** / **HIGH** / **CRITICAL**
Justify with specific reasons (e.g., "HIGH — modifies authentication logic without input validation").

### Issues Found
For EVERY issue (report ALL issues you find, do not limit yourself):
- **Severity**: CRITICAL / WARNING / INFO
  - CRITICAL: bugs, security vulnerabilities, data loss risk, crashes, logic errors that produce wrong results
  - WARNING: potential bugs, missing validation, poor error handling, performance problems, maintainability concerns, coding standard violations
  - INFO: suggestions for improvement, minor readability issues, best practice recommendations
- **File**: exact filename and line number(s)
- **Description**: What is wrong and WHY it is a problem. Be specific — reference the actual code.
- **Current Code**:
\`\`\`
(paste the exact problematic code from the diff)
\`\`\`
- **Suggested Fix**:
\`\`\`
(provide the complete corrected code snippet, ready to copy-paste — not pseudo-code)
\`\`\`
- **Explanation**: Why the fix is better — reference the specific risk being mitigated.

### Common Bug Patterns to Check
Look specifically for these in EVERY review:
- **Null/undefined access**: accessing properties on potentially null/undefined values without checks
- **Missing await**: async functions called without await, causing silent failures or race conditions
- **Resource leaks**: opened connections, file handles, or event listeners not cleaned up
- **SQL injection / XSS / command injection**: unsanitized user input in queries, HTML, or shell commands
- **Hardcoded secrets**: API keys, passwords, tokens, connection strings in code
- **Off-by-one errors**: incorrect loop bounds, array index calculations
- **Type coercion bugs**: loose equality (== vs ===), string-to-number issues
- **Missing error handling**: try/catch missing around I/O, network calls, JSON parsing
- **Incorrect boolean logic**: De Morgan's law violations, wrong operator precedence
- **Copy-paste errors**: duplicated code with incomplete modifications
- **Missing return statements**: functions that should return a value but don't in some paths
- **Event listener leaks**: addEventListener without corresponding removeEventListener
- **Incorrect regex**: patterns that don't match intended input or are vulnerable to ReDoS
- **Race conditions**: shared state modified by concurrent async operations
- **Incorrect string concatenation**: missing separators, wrong interpolation

### Positive Observations
Note 1-3 things done well (good patterns, clean code, thoughtful design).

### Checklist
Mark each as PASS ✅ or FAIL ❌ with brief justification:
- [ ] **Security**: No hardcoded secrets, injection vulnerabilities, XSS, CSRF, insecure deserialization
- [ ] **Error Handling**: All failure paths handled, meaningful error messages, no swallowed exceptions
- [ ] **Edge Cases**: Null checks, empty collections, boundary values, concurrent access
- [ ] **Performance**: No N+1 queries, unnecessary allocations, O(n²) where O(n) is possible, memory leaks
- [ ] **Naming & Readability**: Clear variable/function names, no magic numbers, self-documenting code
- [ ] **Testing**: Changes appear testable, tests included or needed
- [ ] **Documentation**: Public API changes documented, complex logic commented

CRITICAL RULES:
1. For EVERY issue, you MUST include both the current problematic code AND a complete corrected code snippet. No pseudo-code.
2. Do NOT report style-only nitpicks (formatting, trailing whitespace) unless they violate the coding standards above.
3. Do NOT skip issues to keep the review short. Report ALL problems you find.
4. Be specific — reference exact variable names, line numbers, and function names.
5. If you find zero issues, explicitly state that and explain why the code is correct.

IMPORTANT: At the very end of your response, after all other content, output an HTML comment block containing a JSON array of ALL issues you found, in this exact format. This is used to display inline annotations on the diff viewer. Do NOT skip this block even if there are many issues.
<!-- INLINE_COMMENTS_JSON
[{"file":"path/to/file.ext","line":42,"severity":"CRITICAL","message":"Short description of the issue","suggestion":"Corrected code snippet","currentCode":"The problematic code"}]
-->
- "file" must match the filename from the diff header (e.g. "src/utils.js")
- "line" must be the NEW file line number where the issue occurs
- "severity" must be one of: CRITICAL, WARNING, INFO
- "message" is a concise description (1-2 sentences)
- "suggestion" is the corrected code (can be multi-line using \\n)
- "currentCode" is the problematic code from the diff
- Include ALL issues in this JSON array — every issue in your review MUST have a corresponding entry here`;
    }

    // ===== Inline Comments =====
    function extractInlineComments(content) {
        let jsonStr = null;

        // Pattern 1: Standard HTML comment block
        const match1 = content.match(/<!--\s*INLINE_COMMENTS_JSON\s*\n?([\s\S]*?)\n?\s*-->/);
        if (match1) jsonStr = match1[1].trim();

        // Pattern 2: Wrapped in code fences
        if (!jsonStr) {
            const match2 = content.match(/```(?:json)?\s*\n?\s*<!--\s*INLINE_COMMENTS_JSON\s*\n?([\s\S]*?)\n?\s*-->\s*\n?\s*```/);
            if (match2) jsonStr = match2[1].trim();
        }

        // Pattern 3: JSON array after INLINE_COMMENTS_JSON label (no HTML comment wrapper)
        if (!jsonStr) {
            const match3 = content.match(/INLINE_COMMENTS_JSON\s*\n?\s*(\[[\s\S]*?\])\s*(?:-->|$)/);
            if (match3) jsonStr = match3[1].trim();
        }

        if (!jsonStr) {
            console.log('extractInlineComments: no INLINE_COMMENTS_JSON block found in response');
            return [];
        }

        try {
            const parsed = JSON.parse(jsonStr);
            if (!Array.isArray(parsed)) return [];
            return parsed.filter(c => c && c.file && typeof c.line === 'number' && c.message);
        } catch (e) {
            console.warn('extractInlineComments: failed to parse JSON:', e.message, jsonStr.slice(0, 200));
            return [];
        }
    }

    function stripInlineCommentsBlock(content) {
        return content.replace(/\n?<!--\s*INLINE_COMMENTS_JSON\s*\n?[\s\S]*?\n?\s*-->\s*$/, '').trim();
    }

    function findDiffFileEl(fileName) {
        const fileEls = $$('.diff-file');
        for (const el of fileEls) {
            const headerSpan = el.querySelector('.diff-file-header span');
            if (!headerSpan) continue;
            const headerName = headerSpan.textContent.trim();
            if (headerName === fileName) return el;
        }
        // Fuzzy: compare basenames
        const targetBase = fileName.split('/').pop();
        for (const el of fileEls) {
            const headerSpan = el.querySelector('.diff-file-header span');
            if (!headerSpan) continue;
            const headerBase = headerSpan.textContent.trim().split('/').pop();
            if (headerBase === targetBase) return el;
        }
        return null;
    }

    function findDiffLineRow(fileEl, lineNum) {
        const rows = fileEl.querySelectorAll('.diff-table tbody tr');
        let closestRow = null;
        let closestDist = Infinity;
        for (const row of rows) {
            if (row.classList.contains('diff-line-hunk') || row.classList.contains('diff-inline-comment') || row.classList.contains('inline-ask-row')) continue;
            const cells = row.querySelectorAll('td.diff-line-num');
            if (cells.length < 2) continue;
            const newNum = parseInt(cells[1].textContent, 10);
            if (isNaN(newNum)) continue;
            if (newNum === lineNum) return row;
            const dist = Math.abs(newNum - lineNum);
            if (dist < closestDist) {
                closestDist = dist;
                closestRow = row;
            }
        }
        return closestRow; // nearest fallback
    }

    function getDiffContext(fileName, lineNum, radius) {
        radius = radius || 5;
        const files = parseDiff(currentDiff);
        const file = files.find(f => f.name === fileName) || files.find(f => f.name.split('/').pop() === fileName.split('/').pop());
        if (!file) return '';
        const lines = file.lines;
        let targetIdx = -1;
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].newNum === lineNum) { targetIdx = i; break; }
        }
        if (targetIdx === -1) return '';
        const start = Math.max(0, targetIdx - radius);
        const end = Math.min(lines.length - 1, targetIdx + radius);
        const contextLines = [];
        for (let i = start; i <= end; i++) {
            const l = lines[i];
            const prefix = l.type === 'add' ? '+' : l.type === 'del' ? '-' : ' ';
            const marker = i === targetIdx ? '>>>' : '   ';
            contextLines.push(`${marker} ${prefix} ${l.content}`);
        }
        return contextLines.join('\n');
    }

    function annotateInlineComments(comments) {
        // Remove any existing inline annotations
        $$('.diff-inline-comment, .inline-ask-row').forEach(el => el.remove());
        inlineComments = comments;

        if (!comments || comments.length === 0) {
            const toggleBtn = $('#toggle-inline-comments');
            if (toggleBtn) toggleBtn.classList.add('hidden');
            return;
        }

        const toggleBtn = $('#toggle-inline-comments');
        if (toggleBtn) toggleBtn.classList.remove('hidden');

        // Build file element lookup map once (exact name → element, basename → element)
        const fileElMap = new Map();
        const baseNameElMap = new Map();
        $$('.diff-file').forEach(el => {
            const headerSpan = el.querySelector('.diff-file-header span');
            if (!headerSpan) return;
            const name = headerSpan.textContent.trim();
            fileElMap.set(name, el);
            baseNameElMap.set(name.split('/').pop(), el);
        });

        comments.forEach((comment, idx) => {
            const fileEl = fileElMap.get(comment.file)
                || baseNameElMap.get(comment.file.split('/').pop())
                || null;
            if (!fileEl) return;

            const row = findDiffLineRow(fileEl, comment.line);
            if (!row) return;

            const severity = (comment.severity || 'INFO').toUpperCase();
            const severityClass = severity === 'CRITICAL' ? 'severity-critical'
                : severity === 'WARNING' ? 'severity-warning'
                : 'severity-info';

            const commentRow = document.createElement('tr');
            commentRow.className = `diff-inline-comment ${inlineCommentsVisible ? '' : 'hidden'}`;
            commentRow.dataset.severity = severity.toLowerCase();
            commentRow.dataset.commentIdx = idx;

            const td = document.createElement('td');
            td.colSpan = 3;
            td.className = 'inline-comment-cell';

            const severityBorderClass = severity === 'CRITICAL' ? 'inline-comment-critical'
                : severity === 'WARNING' ? 'inline-comment-warning'
                : 'inline-comment-info';

            td.innerHTML = `
                <div class="inline-comment-body ${severityBorderClass}">
                    <div class="inline-comment-header">
                        <span class="${severityClass}">${escapeHtml(severity)}</span>
                        <span class="inline-comment-file">${escapeHtml(comment.file)}:${comment.line}</span>
                    </div>
                    <div class="inline-comment-message">${escapeHtml(comment.message)}</div>
                    ${comment.suggestion ? `
                    <details class="inline-comment-suggestion">
                        <summary>Suggested Fix</summary>
                        <pre><code>${escapeHtml(comment.suggestion)}</code></pre>
                    </details>` : ''}
                    ${comment.currentCode ? `
                    <details class="inline-comment-current">
                        <summary>Current Code</summary>
                        <pre><code>${escapeHtml(comment.currentCode)}</code></pre>
                    </details>` : ''}
                    <div class="inline-comment-actions">
                        <button class="btn btn-ai btn-sm inline-ask-btn" data-comment-idx="${idx}">
                            <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
                                <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM6.5 7.75A.75.75 0 0 1 7.25 7h1a.75.75 0 0 1 .75.75v2.75h.25a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1 0-1.5h.25v-2h-.25a.75.75 0 0 1-.75-.75ZM8 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"/>
                            </svg>
                            Ask AI
                        </button>
                        <button class="btn btn-success btn-sm inline-post-btn" data-comment-idx="${idx}">
                            <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
                                <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 13H8.061l-2.574 2.573A1.458 1.458 0 0 1 3 14.543V13H1.75A1.75 1.75 0 0 1 0 11.25v-8.5C0 1.784.784 1 1.75 1ZM1.5 2.75v8.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h6.5a.25.25 0 0 0 .25-.25v-8.5a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Z"/>
                            </svg>
                            Post
                        </button>
                    </div>
                </div>
            `;

            commentRow.appendChild(td);
            row.after(commentRow);

            // Bind Ask AI button
            td.querySelector('.inline-ask-btn').addEventListener('click', () => toggleInlineAskBar(idx, commentRow));
            // Bind Post to GitHub button — opens editor
            td.querySelector('.inline-post-btn').addEventListener('click', (e) => openPostEditor(idx, commentRow, e.currentTarget));
        });
    }

    function toggleInlineAskBar(commentIdx, commentRow) {
        // Check if ask bar already exists
        let askRow = commentRow.nextElementSibling;
        if (askRow && askRow.classList.contains('inline-ask-row') && askRow.dataset.commentIdx === String(commentIdx)) {
            askRow.remove();
            return;
        }

        askRow = document.createElement('tr');
        askRow.className = `inline-ask-row ${inlineCommentsVisible ? '' : 'hidden'}`;
        askRow.dataset.commentIdx = commentIdx;

        const td = document.createElement('td');
        td.colSpan = 3;
        td.className = 'inline-ask-cell';
        td.innerHTML = `
            <div class="inline-ask-bar">
                <input type="text" class="inline-ask-input" placeholder="Ask about this issue..." autocomplete="off">
                <button class="btn btn-ai btn-sm inline-ask-submit">Ask</button>
            </div>
            <div class="inline-ask-thread"></div>
        `;

        askRow.appendChild(td);
        commentRow.after(askRow);

        const input = td.querySelector('.inline-ask-input');
        const submitBtn = td.querySelector('.inline-ask-submit');
        const thread = td.querySelector('.inline-ask-thread');

        const doAsk = () => handleInlineAsk(commentIdx, input, submitBtn, thread);
        submitBtn.addEventListener('click', doAsk);
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doAsk(); });
        input.focus();
    }

    async function handleInlineAsk(commentIdx, inputEl, btnEl, threadEl) {
        const question = inputEl.value.trim();
        if (!question) return;

        const comment = inlineComments[commentIdx];
        if (!comment) return;

        inputEl.value = '';
        btnEl.disabled = true;

        const pendingId = 'inline-pending-' + Date.now();
        threadEl.innerHTML += `
            <div class="inline-ask-question">You: ${escapeHtml(question)}</div>
            <div class="inline-ask-answer" id="${pendingId}"><em>Thinking...</em></div>
        `;

        const diffContext = getDiffContext(comment.file, comment.line, 5);
        const contextPrompt = `I have a question about an AI review comment on this code.

File: ${comment.file}, Line: ${comment.line}
Severity: ${comment.severity}
AI Comment: ${comment.message}
${comment.suggestion ? `Suggested Fix: ${comment.suggestion}` : ''}

Surrounding diff context:
\`\`\`
${diffContext}
\`\`\`

My question: ${question}`;

        conversationMessages.push({ role: 'user', content: contextPrompt });

        try {
            let streamRenderTimer = null;
            const pendingEl = document.getElementById(pendingId);

            const content = await callAI(conversationMessages, (delta, fullSoFar) => {
                if (streamRenderTimer) return;
                streamRenderTimer = setTimeout(() => {
                    streamRenderTimer = null;
                    if (pendingEl && fullSoFar) {
                        pendingEl.innerHTML = renderMarkdown(fullSoFar);
                    }
                }, 150);
            });

            if (streamRenderTimer) { clearTimeout(streamRenderTimer); streamRenderTimer = null; }
            conversationMessages.push({ role: 'assistant', content });
            if (pendingEl) pendingEl.innerHTML = renderMarkdown(content);
        } catch (err) {
            const pendingEl = document.getElementById(pendingId);
            if (pendingEl) pendingEl.innerHTML = `<span style="color:var(--color-danger)">Error: ${escapeHtml(err.message)}</span>`;
        } finally {
            btnEl.disabled = false;
            inputEl.focus();
        }
    }

    function toggleInlineCommentsVisibility() {
        inlineCommentsVisible = !inlineCommentsVisible;
        $$('.diff-inline-comment, .inline-ask-row, .inline-post-editor-row').forEach(el => {
            el.classList.toggle('hidden', !inlineCommentsVisible);
        });

        // Show only files with comments when visible, all files when hidden
        const filesWithComments = new Set();
        if (inlineCommentsVisible && inlineComments && inlineComments.length > 0) {
            for (const c of inlineComments) {
                const fileEl = findDiffFileEl(c.file);
                if (fileEl) filesWithComments.add(fileEl);
            }
        }

        $$('.diff-file').forEach(el => {
            if (inlineCommentsVisible && filesWithComments.size > 0) {
                // Only show files that have comments
                el.classList.toggle('hidden', !filesWithComments.has(el));
            } else {
                // Show all files
                el.classList.remove('hidden');
            }
        });

        const btn = $('#toggle-inline-comments');
        if (btn) {
            btn.textContent = inlineCommentsVisible ? 'Hide Comments' : 'Show Comments';
        }
    }

    // ===== AI Review =====
    async function runAIReview() {
        if (!CONFIG.AI_ENDPOINT || !CONFIG.AI_API_KEY) {
            showToast('AI endpoint not configured. Set AI_ENDPOINT and AI_API_KEY in config.js.', 'error');
            return;
        }

        if (!currentDiff) {
            showToast('No diff loaded yet. Please wait for the diff to load.', 'error');
            return;
        }

        if (currentDiff.length > CONFIG.MAX_DIFF_SIZE) {
            await reviewChunked();
            return;
        }

        const btn = $('#run-ai-review');
        const loadingEl = $('#ai-review-loading');
        const resultEl = $('#ai-review-result');

        btn.disabled = true;
        loadingEl.classList.remove('hidden');
        resultEl.classList.add('hidden');
        resultEl.innerHTML = '';

        const prTitle = currentPR.title || '';
        const prBody = currentPR.body || '';
        const baseBranch = currentPR.base.ref || '';
        const headBranch = currentPR.head.ref || '';

        const systemPrompt = getSystemPrompt();

        const userPrompt = `PR Title: ${prTitle}
PR Description: ${prBody}
Branch: ${headBranch} → ${baseBranch}

Diff:
\`\`\`diff
${currentDiff}
\`\`\``;

        conversationMessages = [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
        ];

        try {
            // Stream response progressively for faster perceived performance
            loadingEl.classList.add('hidden');
            resultEl.classList.remove('hidden');
            $('#ai-summary-section').style.display = '';
            resultEl.innerHTML = '<p class="streaming-placeholder">Generating review...</p>';

            let streamRenderTimer = null;
            let lastRenderedLength = 0;
            let content;

            try {
                content = await callAI(conversationMessages, (delta, fullSoFar) => {
                    // Throttle DOM updates to every 150ms for performance
                    if (streamRenderTimer) return;
                    streamRenderTimer = setTimeout(() => {
                        streamRenderTimer = null;
                        if (fullSoFar && fullSoFar.length > lastRenderedLength) {
                            lastRenderedLength = fullSoFar.length;
                            const visibleContent = stripInlineCommentsBlock(fullSoFar);
                            resultEl.innerHTML = renderMarkdown(visibleContent);
                        }
                    }, 150);
                });
            } catch (streamErr) {
                // If streaming failed, retry without streaming
                console.warn('Streaming failed, retrying without streaming:', streamErr.message);
                resultEl.innerHTML = '<p class="streaming-placeholder">Generating review...</p>';
                content = await callAI(conversationMessages);
            }

            // Final render with complete content
            if (streamRenderTimer) { clearTimeout(streamRenderTimer); streamRenderTimer = null; }
            conversationMessages.push({ role: 'assistant', content });

            // Extract inline comments and strip the JSON block from visible output
            const comments = extractInlineComments(content);
            const cleanContent = stripInlineCommentsBlock(content);
            console.log(`AI Review: extracted ${comments.length} inline comments from response (content length: ${content.length})`);

            resultEl.innerHTML = renderMarkdown(cleanContent);
            $('#follow-up-section').classList.remove('hidden');
            $('#post-to-github').classList.remove('hidden');
            showToast('AI review complete!', 'success');

            // Clear the hint since we just ran a fresh review
            $('#ai-hint').classList.add('hidden');

            // Always show toggle button after review (even if 0 inline comments extracted)
            const toggleBtn = $('#toggle-inline-comments');
            if (toggleBtn) toggleBtn.classList.remove('hidden');

            // Annotate inline comments on the diff
            annotateInlineComments(comments);

            if (selectedRepo && currentPR) {
                ReviewStore.saveReview(
                    selectedRepo.full_name, currentPR.number,
                    currentPR.title, content, [...conversationMessages],
                    currentPR.head.sha
                ).catch(err => console.error('ReviewStore.saveReview failed:', err));
            }
        } catch (err) {
            loadingEl.classList.add('hidden');
            resultEl.innerHTML = `<div class="empty-state"><p>AI review failed: ${escapeHtml(err.message)}</p></div>`;
            resultEl.classList.remove('hidden');
            $('#ai-summary-section').style.display = '';
            showToast('AI review failed: ' + err.message, 'error');
        } finally {
            btn.disabled = false;
        }
    }

    // ===== Post Editor for Single Comment =====
    function buildDefaultCommentBody(comment) {
        const severity = (comment.severity || 'INFO').toUpperCase();
        let body = `**${severity}**: ${comment.message || ''}`;
        if (comment.suggestion) {
            body += `\n\n**Suggested Fix:**\n\`\`\`\n${comment.suggestion}\n\`\`\``;
        }
        body += `\n\n---\n*Posted by AI PR Reviewer*`;
        return body;
    }

    function openPostEditor(commentIdx, commentRow, btnEl) {
        // If editor already open, close it
        const existing = commentRow.parentElement.querySelector(`.inline-post-editor-row[data-comment-idx="${commentIdx}"]`);
        if (existing) { existing.remove(); return; }

        const comment = inlineComments[commentIdx];
        if (!comment) return;

        const defaultBody = buildDefaultCommentBody(comment);

        const editorRow = document.createElement('tr');
        editorRow.className = 'inline-post-editor-row';
        editorRow.dataset.commentIdx = commentIdx;

        const td = document.createElement('td');
        td.colSpan = 3;
        td.className = 'inline-post-editor-cell';
        td.innerHTML = `
            <div class="inline-post-editor">
                <label class="inline-post-editor-label">Edit comment before posting to GitHub:</label>
                <textarea class="inline-post-editor-textarea" rows="6">${escapeHtml(defaultBody)}</textarea>
                <div class="inline-post-editor-actions">
                    <button class="btn btn-ghost btn-sm inline-post-cancel">Cancel</button>
                    <button class="btn btn-success btn-sm inline-post-submit">Post to GitHub</button>
                </div>
            </div>
        `;
        editorRow.appendChild(td);

        // Insert after the comment row
        commentRow.after(editorRow);

        const textarea = td.querySelector('.inline-post-editor-textarea');
        textarea.focus();
        textarea.setSelectionRange(0, 0);

        td.querySelector('.inline-post-cancel').addEventListener('click', () => editorRow.remove());
        td.querySelector('.inline-post-submit').addEventListener('click', () => {
            const customBody = textarea.value.trim();
            if (!customBody) { showToast('Comment cannot be empty.', 'error'); return; }
            editorRow.remove();
            postSingleCommentToGitHub(commentIdx, btnEl, customBody);
        });
    }

    // ===== Post Single Comment to GitHub =====
    function computeDiffPosition(fileName, targetLine) {
        // Compute the 1-based position within the diff for a given file and line number (new side).
        // GitHub's "position" param is the line offset in the diff (starting from 1 at the first @@ line).
        const files = parseDiff(currentDiff);
        const file = files.find(f => f.name === fileName)
            || files.find(f => f.name.split('/').pop() === fileName.split('/').pop());
        if (!file) return null;

        // Rebuild the diff position counter from the raw diff
        const rawLines = currentDiff.split('\n');
        // Find the section for this file
        const fileHeader = `diff --git a/${file.name} b/${file.name}`;
        let startIdx = -1;
        for (let i = 0; i < rawLines.length; i++) {
            if (rawLines[i].startsWith('diff --git') && rawLines[i].includes(`b/${file.name}`)) {
                startIdx = i;
                break;
            }
        }
        if (startIdx === -1) {
            // Try fuzzy
            const baseName = fileName.split('/').pop();
            for (let i = 0; i < rawLines.length; i++) {
                if (rawLines[i].startsWith('diff --git') && rawLines[i].includes(baseName)) {
                    startIdx = i;
                    break;
                }
            }
        }
        if (startIdx === -1) return null;

        // Find the end of this file's diff
        let endIdx = rawLines.length;
        for (let i = startIdx + 1; i < rawLines.length; i++) {
            if (rawLines[i].startsWith('diff --git ')) {
                endIdx = i;
                break;
            }
        }

        // Walk through lines counting position (starts at 1 from first @@ line)
        let position = 0;
        let newLine = 0;
        let bestPosition = null;
        let bestDist = Infinity;

        for (let i = startIdx; i < endIdx; i++) {
            const line = rawLines[i];
            if (line.startsWith('@@')) {
                position++;
                const hunkMatch = line.match(/@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
                if (hunkMatch) {
                    newLine = parseInt(hunkMatch[1], 10);
                }
                continue;
            }
            if (position === 0) continue; // Before first hunk (file header lines)

            if (line.startsWith('+') && !line.startsWith('+++')) {
                position++;
                if (newLine === targetLine) return position;
                const dist = Math.abs(newLine - targetLine);
                if (dist < bestDist) { bestDist = dist; bestPosition = position; }
                newLine++;
            } else if (line.startsWith('-') && !line.startsWith('---')) {
                position++;
                // Deleted lines don't increment newLine
            } else if (line.startsWith('\\')) {
                // "No newline at end of file" — don't count
            } else {
                // Context line
                position++;
                if (newLine === targetLine) return position;
                const dist = Math.abs(newLine - targetLine);
                if (dist < bestDist) { bestDist = dist; bestPosition = position; }
                newLine++;
            }
        }

        // Return nearest position if exact not found (within 5 lines)
        return bestDist <= 5 ? bestPosition : null;
    }

    async function postSingleCommentToGitHub(commentIdx, btnEl, customBody) {
        if (!currentPR || !selectedRepo) return;
        const comment = inlineComments[commentIdx];
        if (!comment || !comment.file) {
            showToast('Cannot post: missing file info for this comment.', 'error');
            return;
        }

        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;
        const prNumber = currentPR.number;
        const body = customBody || buildDefaultCommentBody(comment);

        const origHTML = btnEl.innerHTML;
        btnEl.disabled = true;
        btnEl.innerHTML = '<span class="spinner"></span>';

        try {
            // Compute the diff position for accurate line placement
            const diffPosition = computeDiffPosition(comment.file, comment.line);

            let payload;
            if (diffPosition) {
                // Use position-based API (most reliable for GHES)
                payload = {
                    body: body,
                    commit_id: currentPR.head.sha,
                    path: comment.file,
                    position: diffPosition,
                };
            } else {
                // Fallback to line-based API (newer GHES versions)
                payload = {
                    body: body,
                    commit_id: currentPR.head.sha,
                    path: comment.file,
                    line: comment.line,
                    side: 'RIGHT',
                };
            }

            // Try posting as a pull request review comment on the specific line
            await apiPost(
                `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${prNumber}/comments`,
                payload,
                token
            );
            btnEl.innerHTML = '\u2713 Posted';
            btnEl.classList.remove('btn-success');
            btnEl.classList.add('btn-ghost');
            showToast(`Comment posted on ${comment.file}:${comment.line}`, 'success');
        } catch (err) {
            // Fallback: post as a regular issue comment mentioning the file/line
            try {
                await apiPost(
                    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/issues/${prNumber}/comments`,
                    { body: body },
                    token
                );
                btnEl.innerHTML = '\u2713 Posted';
                btnEl.classList.remove('btn-success');
                btnEl.classList.add('btn-ghost');
                showToast(`Comment posted (as general comment) for ${comment.file}:${comment.line}`, 'success');
            } catch (err2) {
                btnEl.innerHTML = origHTML;
                btnEl.disabled = false;
                showToast('Failed to post comment: ' + err2.message, 'error');
            }
        }
    }

    // ===== Post All to GitHub =====
    async function postToGitHub() {
        if (!currentPR || !selectedRepo) return;

        const resultEl = $('#ai-review-result');
        const reviewText = resultEl ? resultEl.innerText : '';
        if (!reviewText.trim()) {
            showToast('No review to post. Run AI Review first.', 'error');
            return;
        }

        const owner = selectedRepo.owner.login;
        const name = selectedRepo.name;
        const prNumber = currentPR.number;

        // Build review body from the AI result markdown
        const rawMarkdown = conversationMessages.find(m => m.role === 'assistant');
        let body = rawMarkdown ? stripInlineCommentsBlock(rawMarkdown.content) : reviewText;
        body = `## 🤖 AI Code Review\n\n${body}\n\n---\n*Generated by AI PR Reviewer*`;

        const postBtn = $('#post-to-github');
        postBtn.disabled = true;
        postBtn.innerHTML = '<span class="spinner"></span> Posting...';

        try {
            // Build inline comments array for the GitHub review
            const ghComments = [];
            if (inlineComments && inlineComments.length > 0) {
                for (const c of inlineComments) {
                    if (!c.file || !c.line) continue;
                    const pos = computeDiffPosition(c.file, c.line);
                    if (!pos) continue; // Skip comments we can't map to the diff
                    const commentBody = `**${(c.severity || 'INFO').toUpperCase()}**: ${c.message || ''}${c.suggestion ? '\n\n**Suggestion:**\n```\n' + c.suggestion + '\n```' : ''}`;
                    ghComments.push({
                        path: c.file,
                        position: pos,
                        body: commentBody,
                    });
                }
            }

            const payload = {
                event: 'COMMENT',
                body: body,
            };
            if (ghComments.length > 0) {
                payload.comments = ghComments;
            }

            await apiPost(
                `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${prNumber}/reviews`,
                payload,
                token
            );

            showToast('Review posted to GitHub!', 'success');
        } catch (err) {
            // If inline comments fail (position issues), retry without them
            if (err.message.includes('422') || err.message.includes('position')) {
                try {
                    await apiPost(
                        `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/pulls/${prNumber}/reviews`,
                        { event: 'COMMENT', body: body },
                        token
                    );
                    showToast('Review posted to GitHub (without inline comments).', 'success');
                } catch (err2) {
                    showToast('Failed to post review: ' + err2.message, 'error');
                }
            } else {
                showToast('Failed to post review: ' + err.message, 'error');
            }
        } finally {
            postBtn.disabled = false;
            postBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 13H8.061l-2.574 2.573A1.458 1.458 0 0 1 3 14.543V13H1.75A1.75 1.75 0 0 1 0 11.25v-8.5C0 1.784.784 1 1.75 1ZM1.5 2.75v8.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h6.5a.25.25 0 0 0 .25-.25v-8.5a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Z"/></svg> Post to GitHub`;
        }
    }

    // ===== Simple Markdown Renderer =====
    function renderMarkdown(text) {
        let html = escapeHtml(text);

        // Code blocks (``` ... ```)
        html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
            return `<pre><code>${code.trim()}</code></pre>`;
        });

        // Inline code
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

        // Headers
        html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
        html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
        html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

        // Bold
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        // Italic
        html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

        // Severity badges
        html = html.replace(/\bCRITICAL\b/g, '<span class="severity-critical">CRITICAL</span>');
        html = html.replace(/\bWARNING\b/g, '<span class="severity-warning">WARNING</span>');
        html = html.replace(/\bINFO\b/g, '<span class="severity-info">INFO</span>');
        html = html.replace(/\bHIGH\b/g, '<span class="severity-critical">HIGH</span>');
        html = html.replace(/\bMEDIUM\b/g, '<span class="severity-warning">MEDIUM</span>');
        html = html.replace(/\bLOW\b/g, '<span class="severity-info">LOW</span>');

        // Checkboxes
        html = html.replace(/- \[x\]/gi, '☑');
        html = html.replace(/- \[ \]/g, '☐');

        // Unordered lists
        html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
        html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

        // Blockquotes
        html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');

        // Line breaks (double newline = paragraph)
        html = html.replace(/\n\n/g, '</p><p>');
        html = '<p>' + html + '</p>';

        // Clean up empty paragraphs around block elements
        html = html.replace(/<p>\s*(<h[1-3]>)/g, '$1');
        html = html.replace(/(<\/h[1-3]>)\s*<\/p>/g, '$1');
        html = html.replace(/<p>\s*(<ul>)/g, '$1');
        html = html.replace(/(<\/ul>)\s*<\/p>/g, '$1');
        html = html.replace(/<p>\s*(<pre>)/g, '$1');
        html = html.replace(/(<\/pre>)\s*<\/p>/g, '$1');
        html = html.replace(/<p>\s*(<blockquote>)/g, '$1');
        html = html.replace(/(<\/blockquote>)\s*<\/p>/g, '$1');
        html = html.replace(/<p>\s*<\/p>/g, '');

        return html;
    }

    // ===== View Management =====
    function showLogin() {
        $('#view-login').classList.remove('hidden');
        $('#view-app').classList.add('hidden');
        $('#view-denied').classList.add('hidden');
        $('#user-info').classList.add('hidden');
        $('#logout-btn').classList.add('hidden');
        $('#pat-input').value = CONFIG.DEFAULT_PAT || '';
    }

    function showApp() {
        $('#view-login').classList.add('hidden');
        $('#view-app').classList.remove('hidden');
        $('#view-denied').classList.add('hidden');
        $('#user-info').classList.remove('hidden');
        $('#logout-btn').classList.remove('hidden');
        $('#pr-section').classList.add('hidden');
        $('#review-panel').classList.add('hidden');

        // Show AI config banner if endpoint not set
        if (!CONFIG.AI_ENDPOINT || !CONFIG.AI_API_KEY) {
            $('#ai-config-banner').classList.remove('hidden');
        } else {
            $('#ai-config-banner').classList.add('hidden');
        }

        if (currentUser) {
            $('#user-avatar').src = '../logos/Github.png';
            $('#user-name').textContent = currentUser.login;
        }

        $('#repo-search').value = '';
        renderMostUsedRepos();
    }

    function showAccessDenied() {
        $('#view-login').classList.add('hidden');
        $('#view-app').classList.add('hidden');
        $('#view-denied').classList.remove('hidden');
        $('#user-info').classList.add('hidden');
        $('#logout-btn').classList.remove('hidden');
        const teamList = CONFIG.ACCESS_TEAM_SLUGS
            .map(t => `<strong>${escapeHtml(CONFIG.ACCESS_ORG)}/${escapeHtml(t)}</strong>`)
            .join(' or ');
        $('#denied-message').innerHTML =
            `You must be a member of one of these teams to use this tool: ${teamList}.`;
    }

    // ===== Toast Notifications =====
    function showToast(message, type = 'info') {
        const container = $('#toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 4000);
    }

    // ===== Utility =====
    const _escDiv = document.createElement('div');
    const _escText = document.createTextNode('');
    _escDiv.appendChild(_escText);
    function escapeHtml(str) {
        _escText.nodeValue = str;
        return _escDiv.innerHTML;
    }

    function escapeAttr(str) {
        return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function timeAgo(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const seconds = Math.floor((now - date) / 1000);
        if (seconds < 60) return 'just now';
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;
        const days = Math.floor(hours / 24);
        if (days < 30) return `${days}d ago`;
        const months = Math.floor(days / 30);
        return `${months}mo ago`;
    }

    function isLightColor(hexColor) {
        if (!hexColor) return false;
        const hex = hexColor.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        return brightness > 155;
    }

    // ===== Public API =====
    return { init, handleFollowUp };
})();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', App.init);
} else {
    App.init();
}
