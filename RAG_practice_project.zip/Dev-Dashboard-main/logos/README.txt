Rally Logo Usage
=================

Place the Rally logo image file in this directory with the exact filename:

  Rally.jpg

Requirements / Recommendations:
- Recommended size: square 64x64 or 128x128 px (it will be auto-shrunk to 18x18 in the UI).
- Preferred format: JPG or PNG. If you supply Rally.png you must also either rename it to Rally.jpg or adjust the code.
- Keep the background transparent (if PNG) or white so it looks good on light background.

Fallback Behavior:
- If the file is missing or cannot load, the image element removes itself so links still display cleanly (only the text).

Customizing:
- To change the icon size, edit the CSS rule: `.links li a img.icon { width:18px; height:18px; }` in `Untitled-1.html`.
- To use a different path or filename, search for `logos/Rally.jpg` inside `Untitled-1.html` and update it.

Adding More Logos:
- Follow similar pattern: detect via tag or id inside buildCards() and prepend an <img> with class `icon`.
- Keep file names simple (e.g. Jira.jpg, Confluence.png) and store them in this folder.

Cache Busting:
- If the image does not refresh after replacement, append a query string temporarily (e.g. `logos/Rally.jpg?v=2`).

Authoring Note:
- This README was auto-generated to guide usage; adjust as needed.
