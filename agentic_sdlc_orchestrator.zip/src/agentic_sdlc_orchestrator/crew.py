from crewai import Agent, Task, Crew
from crewai.project import CrewBase, agent, task, crew

@CrewBase
class AgenticSDLC():

    @agent
    def issue_analyst(self):
        return Agent(config=self.agents_config['issue_analyst'])

    @agent
    def repo_context_agent(self):
        return Agent(config=self.agents_config['repo_context_agent'])

    @agent
    def code_generator(self):
        return Agent(config=self.agents_config['code_generator'])

    @agent
    def test_generator(self):
        return Agent(config=self.agents_config['test_generator'])

    @agent
    def debug_agent(self):
        return Agent(config=self.agents_config['debug_agent'])

    @agent
    def pr_agent(self):
        return Agent(config=self.agents_config['pr_agent'])

    @task
    def analyze_issue(self):
        return Task(config=self.tasks_config['analyze_issue'])

    @task
    def get_repo_context(self):
        return Task(config=self.tasks_config['get_repo_context'])

    @task
    def generate_code(self):
        return Task(config=self.tasks_config['generate_code'])

    @task
    def generate_tests(self):
        return Task(config=self.tasks_config['generate_tests'])

    @task
    def run_tests(self):
        return Task(config=self.tasks_config['run_tests'])

    @task
    def debug_code(self):
        return Task(config=self.tasks_config['debug_code'])

    @task
    def create_pr_summary(self):
        return Task(config=self.tasks_config['create_pr_summary'])

    @crew
    def crew(self):
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            verbose=True
        )



# from crewai import Agent, Crew, Process, Task
# from crewai.project import CrewBase, agent, crew, task
# from crewai.agents.agent_builder.base_agent import BaseAgent
# # If you want to run a snippet of code before or after the crew starts,
# # you can use the @before_kickoff and @after_kickoff decorators
# # https://docs.crewai.com/concepts/crews#example-crew-class-with-decorators

# @CrewBase
# class AgenticSdlcOrchestrator():
#     """AgenticSdlcOrchestrator crew"""

#     agents: list[BaseAgent]
#     tasks: list[Task]

#     # Learn more about YAML configuration files here:
#     # Agents: https://docs.crewai.com/concepts/agents#yaml-configuration-recommended
#     # Tasks: https://docs.crewai.com/concepts/tasks#yaml-configuration-recommended
    
#     # If you would like to add tools to your agents, you can learn more about it here:
#     # https://docs.crewai.com/concepts/agents#agent-tools
#     @agent
#     def researcher(self) -> Agent:
#         return Agent(
#             config=self.agents_config['researcher'], # type: ignore[index]
#             verbose=True
#         )

#     @agent
#     def reporting_analyst(self) -> Agent:
#         return Agent(
#             config=self.agents_config['reporting_analyst'], # type: ignore[index]
#             verbose=True
#         )

#     # To learn more about structured task outputs,
#     # task dependencies, and task callbacks, check out the documentation:
#     # https://docs.crewai.com/concepts/tasks#overview-of-a-task
#     @task
#     def research_task(self) -> Task:
#         return Task(
#             config=self.tasks_config['research_task'], # type: ignore[index]
#         )

#     @task
#     def reporting_task(self) -> Task:
#         return Task(
#             config=self.tasks_config['reporting_task'], # type: ignore[index]
#             output_file='report.md'
#         )

#     @crew
#     def crew(self) -> Crew:
#         """Creates the AgenticSdlcOrchestrator crew"""
#         # To learn how to add knowledge sources to your crew, check out the documentation:
#         # https://docs.crewai.com/concepts/knowledge#what-is-knowledge

#         return Crew(
#             agents=self.agents, # Automatically created by the @agent decorator
#             tasks=self.tasks, # Automatically created by the @task decorator
#             process=Process.sequential,
#             verbose=True,
#             # process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
#         )
